package models;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ItemDatabase {
    private static final String FILE_PATH = "items.txt";
    private static List<Item> items = new ArrayList<>();
    
    //  Loads items from file when the class is first used
    static {
        loadItemsFromFile();
    }

    // Adds an item
    public static void addItem(Item item) {
        items.add(item);
        saveItemsToFile();
    }

    // Updates an existing item
    public static void updateItem(String itemCode, String newName, String newSupplierId) {
        Item item = getItemByCode(itemCode);
        if (item != null) {
            item.setItemName(newName);
            item.setSupplierId(newSupplierId);
            saveItemsToFile();
        }
    }

    // Deletes an item
    public static void deleteItem(String itemCode) {
        items.removeIf(item -> item.getItemCode().equalsIgnoreCase(itemCode));
        saveItemsToFile();
    }
    
    // Returns a list of all items in the inventory
    public static List<Item> getAllItems() {
        return items;
    }
    
    // Check for duplicate item code
    public static boolean isItemCodeDuplicate(String itemCode) {
        return items.stream().anyMatch(item -> item.getItemCode().equalsIgnoreCase(itemCode));
    }
    
     // Check for duplicate item name
    public static boolean isItemNameDuplicate(String itemName) {
        return items.stream().anyMatch(item -> item.getItemName().equalsIgnoreCase(itemName));
    }

    // Retrieves an item by its item code
    public static Item getItemByCode(String itemCode) {
        for (Item item : items) {
            if (item.getItemCode().equalsIgnoreCase(itemCode)) {
                return item;
            }
        }
        return null;
    }
    
    // Saves the current list of items to the file
    private static void saveItemsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Item item : items) {
                writer.write(item.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving items to file: " + e.getMessage());
        }
    }
    
    // Loads items from the file into the list
    private static void loadItemsFromFile() {
        items.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String itemCode = parts[0].trim();
                    String itemName = parts[1].trim();
                    String supplierId = parts[2].trim();    
                    items.add(new Item(itemCode, itemName, supplierId));
                }
            }
            System.out.println("Items successfully loaded: " + items);
        } catch (FileNotFoundException e) {
            System.out.println("Items file not found. Starting with an empty inventory.");
        } catch (IOException e) {
            System.err.println("Error loading items from file: " + e.getMessage());
        }
    }
}
