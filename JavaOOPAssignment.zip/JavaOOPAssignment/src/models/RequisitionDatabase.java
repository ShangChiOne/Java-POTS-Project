package models;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class RequisitionDatabase {
    private static final String FILE_PATH = "requisitions.txt";
    private static List<PurchaseRequisition> requisitions = new ArrayList<>();

    // Load requisitions from file when the class is initialized
    static {    
        loadRequisitionsFromFile();
    }

    // Adds a new requisition and saves it to the file
    public static void addRequisition(PurchaseRequisition requisition, String username) {
        // Check if a requisition with the same item code already exists
        for (PurchaseRequisition existing : requisitions) {
            if (existing.getItemCode().equalsIgnoreCase(requisition.getItemCode())) {
                System.out.println("Duplicate requisition found for item code: " + requisition.getItemCode());
                return; // No duplicates
            }
        }

        // Add the requisition if no duplicates are found
        requisitions.add(requisition);
        saveRequisitionsToFile(username);
    }

    // Returns all stored requisitions
    public static List<PurchaseRequisition> getAllRequisitions() {
        return requisitions;
    }

    // Saves requisitions to the file
    private static void saveRequisitionsToFile(String username) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (PurchaseRequisition requisition : requisitions) {
                writer.write(requisition.toString());  
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving requisitions to file: " + e.getMessage());
        }
    }

    // Loads requisitions from the file into memory
    private static void loadRequisitionsFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 7) {  
                    String itemCode = parts[1];
                    int quantity = Integer.parseInt(parts[2]);
                    String supplierCode = parts[3];
                    LocalDate requiredDate = LocalDate.parse(parts[4]);
                    String description = parts[5];
                    String createdBy = parts[6];
                    
                    requisitions.add(new PurchaseRequisition(itemCode, quantity, supplierCode, requiredDate, description, createdBy));
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Requisition file not found, starting with empty requisition list.");
        } catch (IOException e) {
            System.err.println("Error loading requisitions from file: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error parsing requisitions: " + e.getMessage());
        }
    }
}
