package models;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class SupplierDatabase {
    private static final String FILE_PATH = "suppliers.txt";
    private static List<Supplier> suppliers = new ArrayList<>();

    static {
        loadSuppliersFromFile();
    }

    // Add a new supplier to the database and save to file
    public static void addSupplier(Supplier supplier) {
        suppliers.add(supplier);
        saveSuppliersToFile();
    }

    // Get a list of all suppliers
    public static List<Supplier> getAllSuppliers() {
        return suppliers;
    }

    // Get a list of all supplier IDs
    public static List<String> getAllSupplierIds() {
        List<String> supplierIds = new ArrayList<>();
        for (Supplier supplier : suppliers) {
            supplierIds.add(supplier.getSupplierId());
        }
        return supplierIds;
    }

    // Check if a Supplier ID already exists in the database
    public static boolean isSupplierIdDuplicate(String supplierId) {
        return suppliers.stream().anyMatch(supplier -> supplier.getSupplierId().equalsIgnoreCase(supplierId));
    }

    // Update a supplier's information
    public static boolean updateSupplier(String supplierId, String newName, String newContactInfo) {
        for (Supplier supplier : suppliers) {
            if (supplier.getSupplierId().equalsIgnoreCase(supplierId)) {
                supplier.setSupplierName(newName);
                supplier.setContactInfo(newContactInfo);
                saveSuppliersToFile(); // Save changes to file
                return true; // Successfully updated
            }
        }
        return false; // Supplier not found
    }

    // Delete a supplier from the database
    public static boolean deleteSupplier(String supplierId) {
        boolean removed = suppliers.removeIf(supplier -> supplier.getSupplierId().equalsIgnoreCase(supplierId));
        if (removed) {
            saveSuppliersToFile(); // Save updated list to file
        }
        return removed;
    }

    // Save all suppliers to the file
    public static void saveSuppliersToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Supplier supplier : suppliers) {
                writer.write(supplier.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving suppliers to file: " + e.getMessage());
        }
    }

    // Load suppliers from the file into the list
    private static void loadSuppliersFromFile() {
        suppliers.clear(); // Clear existing suppliers before loading
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String supplierId = parts[0];
                    String supplierName = parts[1];
                    String contactInfo = parts[2];
                    suppliers.add(new Supplier(supplierId, supplierName, contactInfo));
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Supplier file not found, starting with empty supplier list.");
        } catch (IOException e) {
            System.err.println("Error loading suppliers from file: " + e.getMessage());
        }
    }
}
