package models;

// Abstract base class for user types.
// Provides common fields and behaviors, and enforces subclass-specific behavior with an abstract method.

public abstract class User {
    protected String userId; 
    protected String username; 
    protected String password; 
    private String role; 

    // Constructor to initialize user attributes
    public User(String userId, String username, String password) {
        this.userId = userId;
        this.username = username;
        this.password = password;
    }

    // Getters and Setters
    public String getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    // Authenticates the user by verifying the password
    public boolean authenticate(String password) {
        return this.password.equals(password);
    }

    // Abstract method to be implemented by subclasses for their main menu behavior
    public abstract void accessMainMenu();
}
