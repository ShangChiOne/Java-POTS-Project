package models;

// Represents an item in the inventory
public class Item {
    private String itemCode;
    private String itemName;
    private String supplierId;

    // Constructor
    public Item(String itemCode, String itemName, String supplierId) {
        this.itemCode = itemCode;
        this.itemName = itemName;
        this.supplierId = supplierId;
    }

    // Getters and Setters
    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    @Override
    public String toString() {
        return itemCode + "," + itemName + "," + supplierId;
    }
}
