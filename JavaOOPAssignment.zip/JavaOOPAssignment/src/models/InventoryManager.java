package models;

// Extends the User class and provides Inventory Manager-specific behavior
public class InventoryManager extends User {
    
    // Constructor 
    public InventoryManager(String userId, String username, String password) {
        super(userId, username, password); // Call the User class constructor
    }

    // Implementation of the abstract method from User class
    // Defines the main menu behavior for an Inventory Manager
    @Override
    public void accessMainMenu() {
        System.out.println("Accessing the main menu as Inventory Manager");
    }
}
