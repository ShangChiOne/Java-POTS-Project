package models;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class Inventory {
    private static final String FILE_PATH = "stock_levels.txt";
    private static Map<String, Integer> stockLevels = new HashMap<>();
    
    // Loads stock data from the file when the class is first used
    static {
        loadStockLevelsFromFile();
    }
    
    // Returns the stock level for a given item code, or 0 if the item is not found
    public static int getStockLevel(String itemCode) {
        return stockLevels.getOrDefault(itemCode, 0);
    }
    
    // Updates the stock level for an item and saves changes to the file
    public static void setStockLevel(String itemCode, int quantity) {
        stockLevels.put(itemCode, quantity);
        saveStockLevelsToFile();
    }
    
    // Saves the current stock levels to the file
    private static void saveStockLevelsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Map.Entry<String, Integer> entry : stockLevels.entrySet()) {
                writer.write(entry.getKey() + "," + entry.getValue());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving stock levels to file: " + e.getMessage());
        }
    }
    
    // Loads stock levels from the file into memory
    private static void loadStockLevelsFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String itemCode = parts[0];
                    int quantity = Integer.parseInt(parts[1]);
                    stockLevels.put(itemCode, quantity);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Stock levels file not found, starting with empty stock levels.");
        } catch (IOException e) {
            System.err.println("Error loading stock levels from file: " + e.getMessage());
        }
    }
}
