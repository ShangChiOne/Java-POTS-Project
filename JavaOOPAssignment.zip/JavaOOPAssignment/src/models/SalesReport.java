package models;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SalesReport {
    
    // Calculates total quantity sold for each item across all sales
    public static Map<String, Integer> generateTotalQuantityPerItem() {
        Map<String, Integer> totalSalesPerItem = new HashMap<>();
        List<SalesEntry> salesEntries = SalesDatabase.getAllSalesEntries();

        for (SalesEntry entry : salesEntries) {
            totalSalesPerItem.put(entry.getItemCode(),
                totalSalesPerItem.getOrDefault(entry.getItemCode(), 0) + entry.getQuantitySold());
        }

        return totalSalesPerItem;
    }

    // Generates total sales per item for a specified date range
    public static Map<String, Integer> generateSalesWithinDateRange(LocalDate startDate, LocalDate endDate) {
        Map<String, Integer> totalSalesPerItem = new HashMap<>();
        List<SalesEntry> salesEntries = SalesDatabase.getAllSalesEntries();

        for (SalesEntry entry : salesEntries) {
            if ((entry.getDate().isEqual(startDate) || entry.getDate().isAfter(startDate)) &&
                (entry.getDate().isEqual(endDate) || entry.getDate().isBefore(endDate))) {

                totalSalesPerItem.put(entry.getItemCode(),
                    totalSalesPerItem.getOrDefault(entry.getItemCode(), 0) + entry.getQuantitySold());
            }
        }

        return totalSalesPerItem;
    }
}
