// models/UserDatabase.java
package models;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class UserDatabase {
    private static Map<String, User> users = new HashMap<>();
    private static final String FILE_PATH = "users.txt";

    // Load users from the file when the class is initialized
    static {
        loadUsersFromFile();
    }

    // Authenticates a user by checking their username and password
    public static User authenticate(String username, String password) {
        User user = users.get(username);
        if (user != null && user.authenticate(password)) {
            return user;
        }
        return null;
    }

    // Adds a new user to the database and saves to file
    public static boolean addUser(User user) {
        if (users.containsKey(user.getUsername())) {
            return false; 
        }
        users.put(user.getUsername(), user);
        saveUsersToFile(); 
        return true;
    }

    // Saves all users to the file in CSV format
    private static void saveUsersToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (User user : users.values()) {
                writer.write(user.getClass().getSimpleName() + "," + user.getUserId() + "," +
                             user.getUsername() + "," + user.getPassword());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving users to file: " + e.getMessage());
        }
    }

    // Loads users from the file into memory
    private static void loadUsersFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    String role = parts[0];
                    String userId = parts[1];
                    String username = parts[2];
                    String password = parts[3];
                    User user = createUserByRole(role, userId, username, password);
                    if (user != null) {
                        users.put(username, user);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("User file not found, starting with empty database.");
        } catch (IOException e) {
            System.err.println("Error loading users from file: " + e.getMessage());
        }
    }

    // Creates a user object based on the role field
    private static User createUserByRole(String role, String userId, String username, String password) {
        switch (role) {
            case "SalesManager":
                return new SalesManager(userId, username, password);
            case "PurchaseManager":
                return new PurchaseManager(userId, username, password);
            case "InventoryManager":
                return new InventoryManager(userId, username, password);
            case "FinanceManager":
                return new FinanceManager(userId, username, password);
            case "Administrator":
                return new Administrator(userId, username, password);
            default:
                return null;
        }
    }
}
