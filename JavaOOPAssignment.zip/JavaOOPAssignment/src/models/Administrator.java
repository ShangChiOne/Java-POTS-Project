package models;

// Extends the User class and provides Administrator-specific behavior
public class Administrator extends User {
    
    // Constructor
    public Administrator(String userId, String username, String password) {
        super(userId, username, password); // Call the User class constructor
    }

    // Implementation of the abstract method from User class
    // Defines the main menu behavior for an Administrator
    @Override
    public void accessMainMenu() {
        System.out.println("Accessing the main menu as Administrator");
    }
}
