package models;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PurchaseOrderDatabase {
    private static final String FILE_PATH = "purchase_orders.txt";
    private static List<PurchaseOrder> purchaseOrders = new ArrayList<>();

    // Loads PO's from file when the class is first used
    static {
        loadPurchaseOrdersFromFile();
    }

    // Adds a new PO and save to file
        public static void addPurchaseOrder(PurchaseOrder purchaseOrder) {
        // Check for duplicates based on requisitionId or itemCode
        for (PurchaseOrder existing : purchaseOrders) {
            if (existing.getRequisitionId().equalsIgnoreCase(purchaseOrder.getRequisitionId())
                    || existing.getItemCode().equalsIgnoreCase(purchaseOrder.getItemCode())) {
                System.out.println("Duplicate Purchase Order found for Requisition ID: " 
                                    + purchaseOrder.getRequisitionId() + " or Item Code: " 
                                    + purchaseOrder.getItemCode());
                return; // No duplicates
            }
        }

        // Add the PO if no duplicates are found
        purchaseOrders.add(purchaseOrder);
        savePurchaseOrdersToFile();
    }


    // Update an existing PO by ID
    public static void updatePurchaseOrder(PurchaseOrder updatedOrder) {
        for (int i = 0; i < purchaseOrders.size(); i++) {
            if (purchaseOrders.get(i).getPurchaseOrderId().equals(updatedOrder.getPurchaseOrderId())) {
                purchaseOrders.set(i, updatedOrder);
                savePurchaseOrdersToFile();
                return;
            }
        }
    }

    // Delete a Purchase Order by ID
    public static void deletePurchaseOrder(String purchaseOrderId) {
        purchaseOrders.removeIf(po -> po.getPurchaseOrderId().equals(purchaseOrderId));
        savePurchaseOrdersToFile();
    }

    // Retrieve all PO's
    public static List<PurchaseOrder> getAllPurchaseOrders() {
        return new ArrayList<>(purchaseOrders);
    }

    // Save all PO's to a file
    private static void savePurchaseOrdersToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (PurchaseOrder purchaseOrder : purchaseOrders) {
                writer.write(purchaseOrder.toString()); // Ensure toString method includes all fields
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving purchase orders to file: " + e.getMessage());
        }
    }

    // Load PO's from a file during initialization
    private static void loadPurchaseOrdersFromFile() {
        purchaseOrders.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6) {  // Check for valid entry
                    String purchaseOrderId = parts[0];
                    String requisitionId = parts[1];
                    String itemCode = parts[2];
                    int quantity = Integer.parseInt(parts[3]);
                    String supplierId = parts[4];
                    String status = parts[5];
                    String rejectionReason = parts.length > 6 ? parts[6] : "";

                    PurchaseOrder purchaseOrder = new PurchaseOrder(purchaseOrderId, requisitionId, itemCode, quantity, supplierId);
                    if ("Approved".equals(status)) {
                        purchaseOrder.approve();
                    } else if ("Rejected".equals(status)) {
                        purchaseOrder.reject(rejectionReason);
                    }
                    purchaseOrders.add(purchaseOrder);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Purchase order file not found, starting with an empty list.");
        } catch (IOException e) {
            System.err.println("Error loading purchase orders from file: " + e.getMessage());
        }
    }
}
