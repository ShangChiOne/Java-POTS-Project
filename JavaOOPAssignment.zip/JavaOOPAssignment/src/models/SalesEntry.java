package models;

import java.time.LocalDate;

public class SalesEntry {
    private String trackerID; 
    private String itemCode;
    private LocalDate date;
    private int quantitySold;

    // Constructor 
    public SalesEntry(String trackerID, String itemCode, LocalDate date, int quantitySold) {
        this.trackerID = trackerID;
        this.itemCode = itemCode;
        this.date = date;
        this.quantitySold = quantitySold;
    }

    // Getter and Setters
    public String getTrackerID() {
        return trackerID;
    }

    public String getItemCode() {
        return itemCode;
    }

    public LocalDate getDate() {
        return date;
    }

    public int getQuantitySold() {
        return quantitySold;
    }

    public void setQuantitySold(int quantitySold) {
        this.quantitySold = quantitySold;
    }

    @Override
    public String toString() {
        return trackerID + "," + itemCode + "," + date + "," + quantitySold;
    }
}
