package models;

public class PurchaseOrder {
    private String purchaseOrderId;
    private String requisitionId;
    private String itemCode;
    private int quantity;
    private String supplierId;
    private boolean isApproved;      
    private String rejectionReason; 

    // Constructor
    public PurchaseOrder(String purchaseOrderId, String requisitionId, String itemCode, int quantity, String supplierId) {
        this.purchaseOrderId = purchaseOrderId;
        this.requisitionId = requisitionId;
        this.itemCode = itemCode;
        this.quantity = quantity;
        this.supplierId = supplierId;
        this.isApproved = false; 
        this.rejectionReason = ""; 
    }

    public String getPurchaseOrderId() {
        return purchaseOrderId;
    }

    // Getters and Setters
    public String getRequisitionId() {
        return requisitionId;
    }

    public String getItemCode() {
        return itemCode;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getSupplierId() {
        return supplierId;
    }

    // Approval Status
    public boolean isApproved() {
        return isApproved;
    }

    // Rejection Status
    public String getRejectionReason() {
        return rejectionReason;
    }

    // Approves the PO
    public void approve() {
        this.isApproved = true;
        this.rejectionReason = "";
    }

    // Rejects the PO
    public void reject(String reason) {
        this.isApproved = false;
        this.rejectionReason = reason;
    }

    @Override
    public String toString() {
        String status = isApproved ? "Approved" : (rejectionReason.isEmpty() ? "Pending" : "Rejected");
        return purchaseOrderId + "," + requisitionId + "," + itemCode + "," + quantity + "," +
                supplierId + "," + status + "," + rejectionReason;
    }
}
