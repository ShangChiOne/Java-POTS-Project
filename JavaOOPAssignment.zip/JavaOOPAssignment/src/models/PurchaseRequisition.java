package models;

import java.time.LocalDate;
import java.util.Random;

public class PurchaseRequisition {
    private String requisitionId;
    private String itemCode;
    private int quantity;
    private String supplierCode;
    private LocalDate requiredDate;
    private String description;
    private String createdBy;  

    // Contstructor
    public PurchaseRequisition(String itemCode, int quantity, String supplierCode, LocalDate requiredDate, String description, String createdBy) {
        this.requisitionId = generateRequisitionId(); 
        this.itemCode = itemCode;
        this.quantity = quantity;
        this.supplierCode = supplierCode;
        this.requiredDate = requiredDate;
        this.description = description;
        this.createdBy = createdBy;
    }

    // Getters
    public String getRequisitionId() {
        return requisitionId;
    }

    public String getItemCode() {
        return itemCode;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getSupplierCode() {
        return supplierCode;
    }

    public LocalDate getRequiredDate() {
        return requiredDate;
    }

    public String getDescription() {
        return description;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    // Generates a random Requisition ID 
    private String generateRequisitionId() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        StringBuilder id = new StringBuilder("PR-");
        for (int i = 0; i < 8; i++) {
            id.append(characters.charAt(random.nextInt(characters.length())));
        }
        return id.toString();
    }

    @Override
    public String toString() {
        return requisitionId + "," + itemCode + "," + quantity + "," + supplierCode + "," + requiredDate + "," + description + "," + createdBy;
    }
}
