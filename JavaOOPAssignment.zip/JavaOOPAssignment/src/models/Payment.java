// models/Payment.java
package models;

import java.time.LocalDate;

public class Payment {
    private String paymentId;
    private String purchaseOrderId;
    private double amount;
    private LocalDate paymentDate;
    private boolean isPaid;

    // Constructor
    public Payment(String paymentId, String purchaseOrderId, double amount, LocalDate paymentDate, boolean isPaid) {
        this.paymentId = paymentId;
        this.purchaseOrderId = purchaseOrderId;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.isPaid = isPaid;
    }

    // Getters and Setters
    public String getPaymentId() {
        return paymentId;
    }

    public String getPurchaseOrderId() {
        return purchaseOrderId;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    // Status of the payment
    public boolean isPaid() {
        return isPaid;
    }

    // Marks the payment as completed
    public void markAsPaid() {
        this.isPaid = true;
    }

    @Override
    public String toString() {
        return paymentId + "," + purchaseOrderId + "," + amount + "," + paymentDate + "," + (isPaid ? "Completed" : "Pending");
    }
}
