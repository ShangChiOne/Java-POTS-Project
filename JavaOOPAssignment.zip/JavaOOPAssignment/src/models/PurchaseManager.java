package models;

// Extends the User class and provides PM-specific behavior
public class PurchaseManager extends User {
    
    // Constructor 
    public PurchaseManager(String userId, String username, String password) {
        super(userId, username, password); // Call the User class constructor
    }

    // Implementation of the abstract method from User class
    // Defines the main menu behavior for a PM
    @Override
    public void accessMainMenu() {
        System.out.println("Accessing the main menu as Purchase Manager");
    }
}