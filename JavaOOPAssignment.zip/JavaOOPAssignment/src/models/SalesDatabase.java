package models;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Set;

public class SalesDatabase {
    private static final String FILE_PATH = "sales.txt";
    private static List<SalesEntry> salesEntries = new ArrayList<>();

    // Load sales entries from the file when the class is initialized
    static {
        loadSalesFromFile();
    }

    // Adds a new sales entry / Updates quantity if the item and date already exist
    public static void addSalesEntry(SalesEntry newEntry) {
        // Check if an entry already exists for the same itemCode and date
        SalesEntry existingEntry = getEntryByItemAndDate(newEntry.getItemCode(), newEntry.getDate());
        if (existingEntry != null) {
            existingEntry.setQuantitySold(existingEntry.getQuantitySold() + newEntry.getQuantitySold());
        } else {
            salesEntries.add(newEntry);
        }

        saveSalesToFile();
    }

    // Deletes a specific sales entry and updates the file
    public static void deleteSalesEntry(SalesEntry entry) {
        salesEntries.remove(entry);
        saveSalesToFile();
    }

    // Finds a sales entry by item code and date
    public static SalesEntry getEntryByItemAndDate(String itemCode, LocalDate date) {
        return salesEntries.stream()
                .filter(entry -> entry.getItemCode().equals(itemCode) && entry.getDate().equals(date))
                .findFirst()
                .orElse(null);
    }

    // Returns all sales entries as a list
    public static List<SalesEntry> getAllSalesEntries() {
        return salesEntries;
    }

    // Retrieves all unique dates from sales entries
    public static Set<LocalDate> getAllUniqueDates() {
        return salesEntries.stream()
                .map(SalesEntry::getDate)
                .collect(Collectors.toSet());
    }

    // Saves the current sales entries to the file
    private static void saveSalesToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (SalesEntry entry : salesEntries) {
                writer.write(entry.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving sales to file: " + e.getMessage());
        }
    }

    // Loads sales entries from the file into memory
    private static void loadSalesFromFile() {
        salesEntries.clear(); // Clear existing data
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    String trackerID = parts[0];
                    String itemCode = parts[1];
                    LocalDate date = LocalDate.parse(parts[2]);
                    int quantitySold = Integer.parseInt(parts[3]);
                    salesEntries.add(new SalesEntry(trackerID,itemCode, date, quantitySold));
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Sales file not found, starting with an empty sales list.");
        } catch (IOException e) {
            System.err.println("Error loading sales from file: " + e.getMessage());
        }
    }
}
