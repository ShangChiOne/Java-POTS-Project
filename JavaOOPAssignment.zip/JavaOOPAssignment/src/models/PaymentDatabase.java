package models;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PaymentDatabase {
    private static final String FILE_PATH = "payments.txt";
    private static List<Payment> payments = new ArrayList<>();

    // Loads payments from file when the class is first used
    static {
        loadPaymentsFromFile();
    }

    // Adds a new payment and saves it to the file
    public static void addPayment(Payment payment) {
        payments.add(payment);
        savePaymentsToFile();
    }

    // Returns all stored payment records
    public static List<Payment> getAllPayments() {
        return payments;
    }

    // Saves the current list of payments to the file
    private static void savePaymentsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Payment payment : payments) {
                writer.write(payment.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving payments to file: " + e.getMessage());
        }
    }

    // Loads payment records from the file into the list
    private static void loadPaymentsFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    String paymentId = parts[0];
                    String purchaseOrderId = parts[1];
                    double amount = Double.parseDouble(parts[2]);
                    LocalDate paymentDate = LocalDate.parse(parts[3]);
                    boolean isPaid = parts[4].equals("Completed");

                    payments.add(new Payment(paymentId, purchaseOrderId, amount, paymentDate, isPaid));
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Payments file not found, starting with empty payments list.");
        } catch (IOException e) {
            System.err.println("Error loading payments from file: " + e.getMessage());
        }
    }
}
