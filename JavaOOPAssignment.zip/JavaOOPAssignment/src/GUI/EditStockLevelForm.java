package gui;

import models.Item;
import models.ItemDatabase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class EditStockLevelForm extends JFrame {
    private JComboBox<String> itemDropdown;
    private JTextField quantityField;
    private JTextField reorderLevelField;
    private JButton editButton;
    private JButton deleteButton;
    private JButton backButton;
    private JFrame previousPage;

    public EditStockLevelForm(JFrame previousPage) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);
        
        // Frame setup
        setTitle("Manage Stock Levels");
        setSize(600, 600);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        // Title label
        JLabel titleLabel = new JLabel("Edit Stock Levels", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(150, 40, 300, 30);
        add(titleLabel);

        // Labels and Input Fields
        JLabel itemLabel = new JLabel("Select Item:");
        itemLabel.setFont(new Font("Arial", Font.BOLD, 16));
        itemLabel.setForeground(Color.WHITE);
        itemLabel.setBounds(100, 120, 150, 30);
        add(itemLabel);

        itemDropdown = new JComboBox<>();
        populateItemDropdown();
        itemDropdown.setFont(new Font("Arial", Font.PLAIN, 14));
        itemDropdown.setBounds(300, 120, 200, 30);
        itemDropdown.addActionListener(e -> autofillFields());
        add(itemDropdown);

        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setFont(new Font("Arial", Font.BOLD, 16));
        quantityLabel.setForeground(Color.WHITE);
        quantityLabel.setBounds(100, 180, 150, 30);
        add(quantityLabel);

        quantityField = new JTextField();
        quantityField.setFont(new Font("Arial", Font.PLAIN, 14));
        quantityField.setBounds(300, 180, 200, 30);
        add(quantityField);

        JLabel reorderLevelLabel = new JLabel("Reorder Level:");
        reorderLevelLabel.setFont(new Font("Arial", Font.BOLD, 16));
        reorderLevelLabel.setForeground(Color.WHITE);
        reorderLevelLabel.setBounds(100, 240, 150, 30);
        add(reorderLevelLabel);

        reorderLevelField = new JTextField();
        reorderLevelField.setFont(new Font("Arial", Font.PLAIN, 14));
        reorderLevelField.setBounds(300, 240, 200, 30);
        add(reorderLevelField);

        // Buttons
        editButton = new JButton("Edit");
        editButton.setFont(new Font("Arial", Font.BOLD, 16));
        editButton.setBounds(100, 340, 120, 40);
        editButton.setBackground(new Color(0, 204, 0)); 
        editButton.addActionListener(this::handleEditButton);
        add(editButton);

        deleteButton = new JButton("Delete");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 16));
        deleteButton.setBounds(250, 340, 120, 40);
        deleteButton.setBackground(new Color(204, 0, 0)); 
        deleteButton.addActionListener(this::handleDeleteButton);
        add(deleteButton);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        backButton.setBounds(400, 340, 120, 40);
        backButton.setBackground(new Color(255, 140, 0)); 
        backButton.addActionListener(e -> {
            dispose();
            previousPage.setVisible(true);
        });
        add(backButton);
    }

    // Populates the item dropdown with item codes
    private void populateItemDropdown() {
        List<String[]> stockLevels = readStockLevels();
        for (String[] stock : stockLevels) {
            itemDropdown.addItem(stock[0]); 
        }
    }

    // Autofills the fields based on the selected item in the dropdown
    private void autofillFields() {
        String selectedItemCode = (String) itemDropdown.getSelectedItem();
        if (selectedItemCode != null) {
            List<String[]> stockLevels = readStockLevels();
            for (String[] stock : stockLevels) {
                if (stock[0].equals(selectedItemCode)) {
                    quantityField.setText(stock[2]); 
                    reorderLevelField.setText(stock[3]); 
                    break;
                }
            }
        }
    }

    // Handles the edit action by updating stock levels
    private void handleEditButton(ActionEvent e) {
        String selectedItemCode = (String) itemDropdown.getSelectedItem();
        String newQuantity = quantityField.getText();
        String newReorderLevel = reorderLevelField.getText();

        if (selectedItemCode == null || newQuantity.isEmpty() || newReorderLevel.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int quantity = Integer.parseInt(newQuantity);
            int reorderLevel = Integer.parseInt(newReorderLevel);
            updateStockLevel(selectedItemCode, quantity, reorderLevel);
            JOptionPane.showMessageDialog(this, "Stock levels updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter valid numbers for quantity and reorder level.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Handles the delete action by removing the selected stock level
    private void handleDeleteButton(ActionEvent e) {
        String selectedItemCode = (String) itemDropdown.getSelectedItem();
        if (selectedItemCode == null) {
            JOptionPane.showMessageDialog(this, "Please select an item to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        deleteStockLevel(selectedItemCode);
        JOptionPane.showMessageDialog(this, "Stock information deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private List<String[]> readStockLevels() {
        List<String[]> stockLevels = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("StockLevels.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stockLevels.add(line.split(","));
            }
        } catch (IOException ex) {
            System.err.println("Error reading stock levels: " + ex.getMessage());
        }
        return stockLevels;
    }

    // Reads the stock levels from the file
    private void updateStockLevel(String itemCode, int quantity, int reorderLevel) {
        List<String[]> stockLevels = readStockLevels();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("StockLevels.txt"))) {
            for (String[] stock : stockLevels) {
                if (stock[0].equals(itemCode)) {
                    writer.write(itemCode + "," + stock[1] + "," + quantity + "," + reorderLevel);
                } else {
                    writer.write(String.join(",", stock));
                }
                writer.newLine();
            }
        } catch (IOException ex) {
            System.err.println("Error updating stock levels: " + ex.getMessage());
        }
    }

    // Deletes the stock level of a specific item
    private void deleteStockLevel(String itemCode) {
        List<String[]> stockLevels = readStockLevels();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("StockLevels.txt"))) {
            for (String[] stock : stockLevels) {
                if (!stock[0].equals(itemCode)) {
                    writer.write(String.join(",", stock));
                    writer.newLine();
                }
            }
        } catch (IOException ex) {
            System.err.println("Error deleting stock level: " + ex.getMessage());
        }
    }
}
