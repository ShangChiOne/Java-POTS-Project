package gui;

import javax.swing.*;
import java.awt.*;
import models.User;
import models.Administrator;
import models.SalesManager;
import models.PurchaseManager;
import models.InventoryManager;
import models.FinanceManager;


public class MainMenu extends JFrame {
    private User user;

    public MainMenu(User user) {
        this.user = user;
        setTitle("Main Menu - " + user.getUsername());
        setSize(600, 600);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        // Welcome label
        JLabel welcomeLabel = new JLabel("Welcome, " + user.getUsername() + "!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setBounds(200, 40, 200, 30); 
        add(welcomeLabel);

        int buttonY = 100;
        int buttonHeight = 40;
        int buttonWidth = 200;

        // Admin-specific options
        if (user instanceof Administrator) {
            // User Management
            JButton manageUsersButton = new JButton("User Management");
            manageUsersButton.setFont(new Font("Arial", Font.BOLD, 14));
            manageUsersButton.setBackground(new Color(211, 211, 211)); 
            manageUsersButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            manageUsersButton.addActionListener(e -> openUserManagement());
            add(manageUsersButton);
            buttonY += 60;
            
            // View Reports
            JButton viewReportsButton = new JButton("View Reports");
            viewReportsButton.setFont(new Font("Arial", Font.BOLD, 14));
            viewReportsButton.setBackground(new Color(211, 211, 211)); 
            viewReportsButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            viewReportsButton.addActionListener(e -> openReports());
            add(viewReportsButton);
            buttonY += 60;
            
            // SM Access
            JButton accessAsSalesManagerButton = new JButton("Access as Sales Manager");
            accessAsSalesManagerButton.setFont(new Font("Arial", Font.BOLD, 14));
            accessAsSalesManagerButton.setBackground(new Color(211, 211, 211));
            accessAsSalesManagerButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            accessAsSalesManagerButton.addActionListener(e -> openRoleMenu("Sales Manager"));
            add(accessAsSalesManagerButton);
            buttonY += 60;
            
            // PM Access
            JButton accessAsPurchaseManagerButton = new JButton("Access as Purchase Manager");
            accessAsPurchaseManagerButton.setFont(new Font("Arial", Font.BOLD, 14));
            accessAsPurchaseManagerButton.setBackground(new Color(211, 211, 211));
            accessAsPurchaseManagerButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            accessAsPurchaseManagerButton.addActionListener(e -> openRoleMenu("Purchase Manager"));
            add(accessAsPurchaseManagerButton);
            buttonY += 60;
            
            // IM Access
            JButton accessAsInventoryManagerButton = new JButton("Access as Inventory Manager");
            accessAsInventoryManagerButton.setFont(new Font("Arial", Font.BOLD, 14));
            accessAsInventoryManagerButton.setBackground(new Color(211, 211, 211));
            accessAsInventoryManagerButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            accessAsInventoryManagerButton.addActionListener(e -> openRoleMenu("Inventory Manager"));
            add(accessAsInventoryManagerButton);
            buttonY += 60;

            // FM Access
            JButton accessAsFinanceManagerButton = new JButton("Access as Finance Manager");
            accessAsFinanceManagerButton.setFont(new Font("Arial", Font.BOLD, 14));
            accessAsFinanceManagerButton.setBackground(new Color(211, 211, 211));
            accessAsFinanceManagerButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            accessAsFinanceManagerButton.addActionListener(e -> openRoleMenu("Finance Manager"));
            add(accessAsFinanceManagerButton);
            buttonY += 60;
        }

        // Sales Manager-specific options
        if (user instanceof SalesManager) {
            //Daily Sales Entry
            JButton dailySalesButton = new JButton("Daily Sales Entry");
            dailySalesButton.setFont(new Font("Arial", Font.BOLD, 14));
            dailySalesButton.setBackground(new Color(211, 211, 211)); 
            dailySalesButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            dailySalesButton.addActionListener(e -> openDailySalesEntry());
            add(dailySalesButton);
            buttonY += 60;
            
            // Create PR
            JButton createPRButton = new JButton("Create Purchase Requisition");
            createPRButton.setFont(new Font("Arial", Font.BOLD, 14));
            createPRButton.setBackground(new Color(211, 211, 211)); 
            createPRButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            createPRButton.addActionListener(e -> openCreatePR());
            add(createPRButton);
            buttonY += 60;
            
            // Sales Report
            JButton salesReportButton = new JButton("Sales Report");
            salesReportButton.setFont(new Font("Arial", Font.BOLD, 14));
            salesReportButton.setBackground(new Color(211, 211, 211)); 
            salesReportButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            salesReportButton.addActionListener(e -> openReports());
            add(salesReportButton);
            buttonY += 60;
            
            // List of Items
            JButton listOfItemsButton = new JButton("List of Items");
            listOfItemsButton.setFont(new Font("Arial", Font.BOLD, 14));
            listOfItemsButton.setBackground(new Color(211, 211, 211));
            listOfItemsButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            listOfItemsButton.addActionListener(e -> openListOfItems());
            add(listOfItemsButton);
            buttonY += 60;
            
            // PO List
            JButton listOfPurchaseOrdersButton = new JButton("List of Purchase Orders");
            listOfPurchaseOrdersButton.setFont(new Font("Arial", Font.BOLD, 14));
            listOfPurchaseOrdersButton.setBackground(new Color(211, 211, 211));
            listOfPurchaseOrdersButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            listOfPurchaseOrdersButton.addActionListener(e -> listOfPurchaseOrders());
            add(listOfPurchaseOrdersButton);
            buttonY += 60;
            
            // Check Stock Status
            JButton checkStockStatusButton = new JButton("Check Stock Status");
            checkStockStatusButton.setFont(new Font("Arial", Font.BOLD, 14));
            checkStockStatusButton.setBackground(new Color(211, 211, 211)); 
            checkStockStatusButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            checkStockStatusButton.addActionListener(e -> openStockStatusView());
            add(checkStockStatusButton);
            buttonY += 60;
        }

        // Purchase Manager-specific options
        if (user instanceof PurchaseManager) {
            // View Requisition
            JButton viewRequisitionsButton = new JButton("View Requisitions");
            viewRequisitionsButton.setFont(new Font("Arial", Font.BOLD, 14));
            viewRequisitionsButton.setBackground(new Color(211, 211, 211)); 
            viewRequisitionsButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            viewRequisitionsButton.addActionListener(e -> openViewRequisitions());
            add(viewRequisitionsButton);
            buttonY += 60;
            
            // Generate PO
            JButton generatePOButton = new JButton("Generate Purchase Order");
            generatePOButton.setFont(new Font("Arial", Font.BOLD, 14));
            generatePOButton.setBackground(new Color(211, 211, 211)); 
            generatePOButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            generatePOButton.addActionListener(e -> openGeneratePO());
            add(generatePOButton);
            buttonY += 60;
            
            // List of Items
            JButton listOfItemsButton = new JButton("List of Items");
            listOfItemsButton.setFont(new Font("Arial", Font.BOLD, 14));
            listOfItemsButton.setBackground(new Color(211, 211, 211));
            listOfItemsButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            listOfItemsButton.addActionListener(e -> openListOfItems());
            add(listOfItemsButton);
            buttonY += 60;
            
            // List of Suppliers
            JButton listOfSuppliersButton = new JButton("List of Suppliers");
            listOfSuppliersButton.setFont(new Font("Arial", Font.BOLD, 14));
            listOfSuppliersButton.setBackground(new Color(211, 211, 211));
            listOfSuppliersButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            listOfSuppliersButton.addActionListener(e -> openListOfSuppliers());
            add(listOfSuppliersButton);
            buttonY += 60;
            
            // Create Requisition
            JButton createPRButton = new JButton("Create Purchase Requisition");
            createPRButton.setFont(new Font("Arial", Font.BOLD, 14));
            createPRButton.setBackground(new Color(211, 211, 211));
            createPRButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            createPRButton.addActionListener(e -> openCreatePR());
            add(createPRButton);
            buttonY += 60;
            
            //PO List
            JButton listOfPurchaseOrdersButton = new JButton("List of Purchase Orders");
            listOfPurchaseOrdersButton.setFont(new Font("Arial", Font.BOLD, 14));
            listOfPurchaseOrdersButton.setBackground(new Color(211, 211, 211));
            listOfPurchaseOrdersButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            listOfPurchaseOrdersButton.addActionListener(e -> listOfPurchaseOrders());
            add(listOfPurchaseOrdersButton);
            buttonY += 60;
        }

        // Inventory Manager-specific options
        if (user instanceof InventoryManager) {
            // Item Entry
            JButton itemEntryButton = new JButton("Item Entry");
            itemEntryButton.setFont(new Font("Arial", Font.BOLD, 14));
            itemEntryButton.setBackground(new Color(211, 211, 211)); 
            itemEntryButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            itemEntryButton.addActionListener(e -> openItemEntry());
            add(itemEntryButton);
            buttonY += 60;
            
            // Supplier Entry
            JButton supplierEntryButton = new JButton("Supplier Entry");
            supplierEntryButton.setFont(new Font("Arial", Font.BOLD, 14));
            supplierEntryButton.setBackground(new Color(211, 211, 211)); 
            supplierEntryButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            supplierEntryButton.addActionListener(e -> openSupplierEntry());
            add(supplierEntryButton);
            buttonY += 60;
            
            // Manage Stock Level
            JButton manageStockLevelButton = new JButton("Manage Stock Level");
            manageStockLevelButton.setFont(new Font("Arial", Font.BOLD, 14));
            manageStockLevelButton.setBackground(new Color(211, 211, 211));
            manageStockLevelButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            manageStockLevelButton.addActionListener(e -> openManageStockLevel());
            add(manageStockLevelButton);
            buttonY += 60;
            
            // View Stock Levels
            JButton checkStockStatusButton = new JButton("View Stock Levels");
            checkStockStatusButton.setFont(new Font("Arial", Font.BOLD, 14));
            checkStockStatusButton.setBackground(new Color(211, 211, 211)); 
            checkStockStatusButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            checkStockStatusButton.addActionListener(e -> openStockStatusView());
            add(checkStockStatusButton);
            buttonY += 60;
        }

        // Finance Manager-specific options
        if (user instanceof FinanceManager) {
            // Approve/Reject PO
            JButton approvePOButton = new JButton("Approve/Reject PO");
            approvePOButton.setFont(new Font("Arial", Font.BOLD, 14));
            approvePOButton.setBackground(new Color(211, 211, 211)); 
            approvePOButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            approvePOButton.addActionListener(e -> openApprovePO());
            add(approvePOButton);
            buttonY += 60;
            
            // Make Payments
            JButton viewPaymentsButton = new JButton("Make Payments");
            viewPaymentsButton.setFont(new Font("Arial", Font.BOLD, 14));
            viewPaymentsButton.setBackground(new Color(211, 211, 211));
            viewPaymentsButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            viewPaymentsButton.addActionListener(e -> openViewPayments());
            add(viewPaymentsButton);
            buttonY += 60;
            
            // View Payment History
            JButton viewPaymentHistoryButton = new JButton("View Payment History");
            viewPaymentHistoryButton.setFont(new Font("Arial", Font.BOLD, 14));
            viewPaymentHistoryButton.setBackground(new Color(211, 211, 211)); 
            viewPaymentHistoryButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            viewPaymentHistoryButton.addActionListener(e -> openPaymentHistory());
            add(viewPaymentHistoryButton);
            buttonY += 60;
            
            // Check Stock Status
            JButton checkStockStatusButton = new JButton("Check Stock Status");
            checkStockStatusButton.setFont(new Font("Arial", Font.BOLD, 14));
            checkStockStatusButton.setBackground(new Color(211, 211, 211)); 
            checkStockStatusButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
            checkStockStatusButton.addActionListener(e -> openStockStatusView());
            add(checkStockStatusButton);
            buttonY += 60;
        }
        
        // Logout Button
        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 14));
        logoutButton.setBackground(new Color(255, 140, 0)); 
        logoutButton.setBounds(200, buttonY, buttonWidth, buttonHeight);
        logoutButton.addActionListener(e -> logout());
        add(logoutButton);
    }
    
    private void openRoleMenu(String role) {
        User roleUser = null;

        switch (role) {
            case "Sales Manager":
                roleUser = new SalesManager("admin", "Admin", "password"); 
                break;
            case "Purchase Manager":
                roleUser = new PurchaseManager("admin", "Admin", "password");
                break;
            case "Inventory Manager":
                roleUser = new InventoryManager("admin", "Admin", "password");
                break;
            case "Finance Manager":
                roleUser = new FinanceManager("admin", "Admin", "password");
                break;
            default:
                JOptionPane.showMessageDialog(this, "Invalid role selected.");
                return;
        }

        // Reopen MainMenu with the new role user
        new MainMenu(roleUser).setVisible(true);
        this.dispose(); 
    }
    
    // Navigation Methods
    private void logout() {
        this.dispose(); 
        new LoginScreen().setVisible(true); 
    }

    private void openUserManagement() {
        new UserRegistrationForm(this).setVisible(true);
    }

    private void openReports() {
        new SalesReportView(this, user).setVisible(true);
    }
 
    
    private void openDailySalesEntry() {
        new SalesEntryForm(this).setVisible(true);
    }

    private void openCreatePR() {
        new PurchaseRequisitionForm(this, user).setVisible(true);
    }

    private void openViewRequisitions() {
        new ViewRequisitions(this).setVisible(true);
    }

    private void openGeneratePO() {
        new PurchaseOrderForm(this).setVisible(true);
    }
    
    private void openListOfItems() {
        new ListOfItemsGUI(this).setVisible(true);
    }
    
    private void openListOfSuppliers() {
        new ListOfSuppliersGUI(this).setVisible(true);
    }

    private void openItemEntry() {
        new ItemEntryForm(this, user).setVisible(true);
    }

    private void openSupplierEntry() {
        new SupplierEntryForm(this, user).setVisible(true);
    }

    private void openApprovePO() {
        new PurchaseOrderApprovalForm(this, user).setVisible(true);
    }

    private void openViewPayments() {
        new PaymentManagementForm(this, user).setVisible(true);
    }
    
    private void openPaymentHistory() {
        new PaymentHistoryView(this).setVisible(true);
    }

    private void openStockStatusView() {
        new StockStatusView(this).setVisible(true);
    }
    
    private void listOfPurchaseOrders() {
        new ViewPurchaseOrderList(this).setVisible(true);
    }
    
    private void openManageStockLevel() {
        new StockLevelUpdateForm(this).setVisible(true);
    }
}
