package gui;

import javax.swing.*;
import java.awt.*;
import models.Supplier;
import models.User;
import models.SupplierDatabase;
import java.awt.event.ActionEvent;

public class EditSupplierEntryForm extends JFrame {
    private JComboBox<String> supplierIdComboBox;
    private JTextField supplierNameField;
    private JTextField contactInfoField;
    private JButton editButton;
    private JButton deleteButton;
    private User user;
    private JFrame previousPage;

    public EditSupplierEntryForm(JFrame previousPage, User user) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);
        this.user = user;
        
        // Frame setup
        setTitle("Edit Supplier Entry Form");
        setSize(600, 600);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        // Supplier ID Label and Dropdown
        JLabel supplierIdLabel = new JLabel("Supplier ID:");
        supplierIdLabel.setFont(new Font("Arial", Font.BOLD, 16));
        supplierIdLabel.setForeground(Color.WHITE);
        supplierIdLabel.setBounds(200, 120, 200, 30); 
        add(supplierIdLabel);

        supplierIdComboBox = new JComboBox<>();
        supplierIdComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        supplierIdComboBox.setBackground(new Color(105, 105, 105)); 
        supplierIdComboBox.setForeground(Color.WHITE);
        supplierIdComboBox.setBounds(200, 160, 200, 30); 
        populateSupplierIdComboBox();
        supplierIdComboBox.addActionListener(e -> loadSupplierDetails());
        add(supplierIdComboBox);

        // Supplier Name Label and Field
        JLabel supplierNameLabel = new JLabel("Supplier Name:");
        supplierNameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        supplierNameLabel.setForeground(Color.WHITE);
        supplierNameLabel.setBounds(200, 200, 200, 30); 
        add(supplierNameLabel);

        supplierNameField = new JTextField();
        supplierNameField.setFont(new Font("Arial", Font.PLAIN, 14));
        supplierNameField.setBackground(new Color(105, 105, 105)); 
        supplierNameField.setForeground(Color.WHITE);
        supplierNameField.setBounds(200, 240, 200, 30); 
        add(supplierNameField);

        // Contact Info Label and Field
        JLabel contactInfoLabel = new JLabel("Contact Info (+60):");
        contactInfoLabel.setFont(new Font("Arial", Font.BOLD, 16));
        contactInfoLabel.setForeground(Color.WHITE);
        contactInfoLabel.setBounds(200, 280, 200, 30); 
        add(contactInfoLabel);

        contactInfoField = new JTextField();
        contactInfoField.setFont(new Font("Arial", Font.PLAIN, 14));
        contactInfoField.setBackground(new Color(105, 105, 105)); 
        contactInfoField.setForeground(Color.WHITE);
        contactInfoField.setBounds(200, 320, 200, 30); 
        add(contactInfoField);

        // Edit Supplier Button
        editButton = new JButton("Edit Supplier");
        editButton.setFont(new Font("Arial", Font.BOLD, 14));
        editButton.setBackground(new Color(11, 136, 255)); 
        editButton.setBounds(150, 380, 150, 40);
        editButton.addActionListener(e -> editSupplier());
        add(editButton);

        // Delete Supplier Button
        deleteButton = new JButton("Delete Supplier");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteButton.setBackground(new Color(255, 69, 0)); 
        deleteButton.setBounds(310, 380, 150, 40);
        deleteButton.addActionListener(e -> deleteSupplier());
        add(deleteButton);

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0)); 
        backButton.setBounds(200, 440, 200, 40); 
        backButton.addActionListener(e -> goBack());
        add(backButton);
    }

    // Populate supplier ID dropdown with all supplier IDs
    private void populateSupplierIdComboBox() {
        supplierIdComboBox.removeAllItems();
        for (String supplierId : SupplierDatabase.getAllSupplierIds()) {
            supplierIdComboBox.addItem(supplierId);
        }
        supplierIdComboBox.setSelectedIndex(-1); 
    }

    // Load details of the selected supplier into the input fields
    private void loadSupplierDetails() {
        String selectedId = (String) supplierIdComboBox.getSelectedItem();
        if (selectedId != null) {
            Supplier supplier = SupplierDatabase.getAllSuppliers().stream()
                    .filter(s -> s.getSupplierId().equals(selectedId))
                    .findFirst()
                    .orElse(null);
            if (supplier != null) {
                supplierNameField.setText(supplier.getSupplierName());
                contactInfoField.setText(supplier.getContactInfo());
            }
        }
    }

    // Edit the supplier details
    private void editSupplier() {
        String supplierId = (String) supplierIdComboBox.getSelectedItem();
        String supplierName = supplierNameField.getText();
        String contactInfo = contactInfoField.getText();

        if (supplierId == null || supplierName.isEmpty() || contactInfo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }

        // Update the supplier
        boolean updated = false;
        for (Supplier supplier : SupplierDatabase.getAllSuppliers()) {
            if (supplier.getSupplierId().equals(supplierId)) {
                supplier.setSupplierName(supplierName);
                supplier.setContactInfo(contactInfo);
                updated = true;
                break;
            }
        }

        if (updated) {
            SupplierDatabase.saveSuppliersToFile(); 
            JOptionPane.showMessageDialog(this, "Supplier updated successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update supplier.");
        }

        clearForm();
    }

    // Delete the selected supplier
    private void deleteSupplier() {
        String supplierId = (String) supplierIdComboBox.getSelectedItem();
        if (supplierId == null) {
            JOptionPane.showMessageDialog(this, "Please select a supplier to delete.");
            return;
        }

        // Delete the supplier
        boolean removed = SupplierDatabase.getAllSuppliers().removeIf(s -> s.getSupplierId().equals(supplierId));

        if (removed) {
            SupplierDatabase.saveSuppliersToFile(); 
            populateSupplierIdComboBox(); 
            JOptionPane.showMessageDialog(this, "Supplier deleted successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to delete supplier.");
        }

        clearForm();
    }

    // Clear all fields in the form
    private void clearForm() {
        supplierIdComboBox.setSelectedIndex(-1);
        supplierNameField.setText("");
        contactInfoField.setText("");
    }

    // Navigate back to the previous page
    private void goBack() {
        this.dispose(); 
        previousPage.setVisible(true); 
    }
}
