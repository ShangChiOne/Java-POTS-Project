package gui;

import javax.swing.*;
import java.awt.*;
import models.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserRegistrationForm extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleComboBox;
    private JButton registerButton;
    private JButton clearButton;
    private JButton backButton;
    private JFrame previousPage;

    public UserRegistrationForm(JFrame previousPage) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);
        
        // Frame Setup
        setTitle("User Registration");
        setSize(600, 600);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        // Username Label and Field
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        usernameLabel.setForeground(Color.WHITE);
        usernameLabel.setBounds(150, 20, 300, 30);
        add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        usernameField.setBackground(new Color(105, 105, 105)); 
        usernameField.setForeground(Color.WHITE); 
        usernameField.setBounds(150, 50, 300, 30);
        add(usernameField);

        // Password Label and Field
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setBounds(150, 90, 300, 30);
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordField.setBackground(new Color(105, 105, 105)); 
        passwordField.setForeground(Color.WHITE); 
        passwordField.setBounds(150, 120, 300, 30);
        add(passwordField);

        // Role Label and ComboBox
        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        roleLabel.setForeground(Color.WHITE);
        roleLabel.setBounds(150, 160, 300, 30);
        add(roleLabel);

        String[] roles = {"Sales Manager", "Purchase Manager", "Inventory Manager", "Finance Manager", "Administrator"};
        roleComboBox = new JComboBox<>(roles);
        roleComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        roleComboBox.setBackground(new Color(105, 105, 105)); 
        roleComboBox.setForeground(Color.WHITE); 
        roleComboBox.setBounds(150, 190, 300, 30);
        add(roleComboBox);

        // Register Button
        registerButton = new JButton("Register");
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        registerButton.setBackground(new Color(11, 136, 255)); 
        registerButton.setBounds(150, 250, 300, 40);
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });
        add(registerButton);

        // Clear Button
        clearButton = new JButton("Clear");
        clearButton.setFont(new Font("Arial", Font.BOLD, 14));
        clearButton.setBackground(new Color(211, 211, 211)); 
        clearButton.setBounds(150, 310, 300, 40);
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearForm();
            }
        });
        add(clearButton);

        // Back Button
        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0)); 
        backButton.setBounds(150, 370, 300, 40);
        backButton.addActionListener(e -> {
            dispose();
            previousPage.setVisible(true);
        });
        add(backButton);
    }

    // Register a new user
    private void registerUser() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String role = (String) roleComboBox.getSelectedItem();
        
        // Validate the input fields
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }

        // Create a user object based on the selected role
        User newUser = createUserByRole(username, password, role);

        // Add the user to the database
        if (newUser != null && UserDatabase.addUser(newUser)) {
            JOptionPane.showMessageDialog(this, "User registered successfully!");
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Username already exists or invalid role.");
        }
    }

    // Create a user object based on the selected role
    private User createUserByRole(String username, String password, String role) {
        switch (role) {
            case "Sales Manager":
                return new SalesManager("SM_" + username, username, password);
            case "Purchase Manager":
                return new PurchaseManager("PM_" + username, username, password);
            case "Inventory Manager":
                return new InventoryManager("IM_" + username, username, password);
            case "Finance Manager":
                return new FinanceManager("FM_" + username, username, password);
            case "Administrator":
                return new Administrator("AD_" + username, username, password);
            default:
                return null;
        }
    }

    // Clear the form fields
    private void clearForm() {
        usernameField.setText("");
        passwordField.setText("");
        roleComboBox.setSelectedIndex(0);
    }
}
