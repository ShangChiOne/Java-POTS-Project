package gui;

import javax.swing.*;
import java.awt.*;
import models.Payment;
import models.PaymentDatabase;
import models.PurchaseOrder;
import models.PurchaseOrderDatabase;
import models.User;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.UUID;

public class PaymentManagementForm extends JFrame {
    private JComboBox<String> purchaseOrderComboBox;
    private JTextField amountField;
    private JTextField paymentDateField;
    private JButton makePaymentButton;
    private JButton backButton;

    // Frame Setup
    public PaymentManagementForm(JFrame previousPage, User user) {
        previousPage.setVisible(false);
        setTitle("Payment Management");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK);

        // Approved Purchase Order selection dropdown
        JLabel poLabel = new JLabel("Select Approved PO:");
        poLabel.setFont(new Font("Arial", Font.BOLD, 16));
        poLabel.setForeground(Color.WHITE);
        poLabel.setBounds(150, 20, 300, 30);
        add(poLabel);

        purchaseOrderComboBox = new JComboBox<>();
        purchaseOrderComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        purchaseOrderComboBox.setBackground(new Color(105, 105, 105));
        purchaseOrderComboBox.setForeground(Color.WHITE);
        purchaseOrderComboBox.setBounds(150, 50, 300, 30);
        populatePurchaseOrderComboBox();
        add(purchaseOrderComboBox);

        // Amount field
        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setFont(new Font("Arial", Font.BOLD, 16));
        amountLabel.setForeground(Color.WHITE);
        amountLabel.setBounds(150, 90, 300, 30);
        add(amountLabel);

        amountField = new JTextField();
        amountField.setFont(new Font("Arial", Font.PLAIN, 14));
        amountField.setBackground(new Color(105, 105, 105));
        amountField.setForeground(Color.WHITE);
        amountField.setBounds(150, 120, 300, 30);
        add(amountField);

        // Payment Date field
        JLabel dateLabel = new JLabel("Payment Date:");
        dateLabel.setFont(new Font("Arial", Font.BOLD, 16));
        dateLabel.setForeground(Color.WHITE);
        dateLabel.setBounds(150, 160, 300, 30);
        add(dateLabel);

        paymentDateField = new JTextField(LocalDate.now().toString());
        paymentDateField.setFont(new Font("Arial", Font.PLAIN, 14));
        paymentDateField.setBackground(new Color(105, 105, 105));
        paymentDateField.setForeground(Color.WHITE);
        paymentDateField.setBounds(150, 190, 300, 30);
        add(paymentDateField);

        // Make Payment button
        makePaymentButton = new JButton("Make Payment");
        makePaymentButton.setFont(new Font("Arial", Font.BOLD, 14));
        makePaymentButton.setBackground(new Color(11, 136, 255));
        makePaymentButton.setBounds(200, 250, 200, 40);
        makePaymentButton.addActionListener(e -> makePayment());
        add(makePaymentButton);

        // Back button
        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0));
        backButton.setBounds(200, 310, 200, 40);
        backButton.addActionListener(e -> {
            dispose();
            previousPage.setVisible(true);
        });
        add(backButton);
    }

    // Populate the dropdown with approved purchase orders
    private void populatePurchaseOrderComboBox() {
        purchaseOrderComboBox.removeAllItems();
        for (PurchaseOrder order : PurchaseOrderDatabase.getAllPurchaseOrders()) {
            if (order.isApproved()) {
                purchaseOrderComboBox.addItem(order.getPurchaseOrderId());
            }
        }
    }

    // Process and save the payment
    private void makePayment() {
        String purchaseOrderId = (String) purchaseOrderComboBox.getSelectedItem();
        String amountText = amountField.getText();
        String dateText = paymentDateField.getText();

        if (purchaseOrderId == null || amountText.isEmpty() || dateText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Amount must be a valid number.");
            return;
        }

        LocalDate paymentDate;
        try {
            paymentDate = LocalDate.parse(dateText);
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Please use YYYY-MM-DD.");
            return;
        }

        // Generate a unique payment ID
        String paymentId = "PAY-" + UUID.randomUUID().toString().substring(0, 8);

        // Create and save the Payment object
        Payment payment = new Payment(paymentId, purchaseOrderId, amount, paymentDate, true);
        PaymentDatabase.addPayment(payment);

        JOptionPane.showMessageDialog(this, "Payment recorded successfully!");
        clearForm();
    }

    // Reset the input fields to their default states
    private void clearForm() {
        purchaseOrderComboBox.setSelectedIndex(0);
        amountField.setText("");
        paymentDateField.setText(LocalDate.now().toString());
    }
}
