package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import models.User;
import models.UserDatabase;

public class LoginScreen extends JFrame implements ActionListener {
    private JTextField userField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginScreen() {
        // Frame Setup
        setTitle("POTS Login");
        setSize(600, 600);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        // Username Label and Field
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Arial", Font.BOLD, 16));
        userLabel.setForeground(Color.WHITE);
        userLabel.setBounds(225, 150, 150, 30); 
        add(userLabel);

        userField = new JTextField();
        userField.setFont(new Font("Arial", Font.PLAIN, 14));
        userField.setBackground(new Color(105, 105, 105)); 
        userField.setForeground(Color.WHITE); 
        userField.setBounds(225, 190, 150, 30); 
        add(userField);

        // Password Label and Field
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setBounds(225, 230, 150, 30); 
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordField.setBackground(new Color(105, 105, 105)); 
        passwordField.setForeground(Color.WHITE); 
        passwordField.setBounds(225, 260, 150, 30); 
        add(passwordField);

        // Login Button
        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.setBackground(new Color(255, 140, 0)); 
        loginButton.setBounds(250, 320, 100, 40); 
        loginButton.addActionListener(this);
        add(loginButton);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String username = userField.getText();
        String password = new String(passwordField.getPassword());

        // Authenticate user
        User user = UserDatabase.authenticate(username, password);

        if (user != null) {
            JOptionPane.showMessageDialog(this, "Login Successful");
            new MainMenu(user).setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials");
        }
    }
}

