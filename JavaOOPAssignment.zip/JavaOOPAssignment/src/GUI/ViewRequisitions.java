package gui;

import models.PurchaseRequisition;
import models.RequisitionDatabase;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ViewRequisitions extends JFrame {
    private JTable requisitionTable;
    private DefaultTableModel tableModel;
    private JFrame mainMenu;

    public ViewRequisitions(JFrame mainMenu) {
        this.mainMenu = mainMenu;
        mainMenu.setVisible(false);

        // Set up the frame
        setTitle("View Purchase Requisitions");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        // Title label
        JLabel titleLabel = new JLabel("Purchase Requisitions", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(150, 20, 300, 30); 
        add(titleLabel);

        // Table setup with updated column names
        String[] columnNames = {"Requisition ID", "Item Code", "Quantity", "Supplier Code", "Required Date", "Description"};
        tableModel = new DefaultTableModel(columnNames, 0);
        requisitionTable = new JTable(tableModel);
        requisitionTable.setFont(new Font("Arial", Font.PLAIN, 14));
        requisitionTable.setBackground(new Color(105, 105, 105)); 
        requisitionTable.setForeground(Color.WHITE); 
        requisitionTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        requisitionTable.getTableHeader().setBackground(new Color(255, 140, 0)); 
        requisitionTable.getTableHeader().setForeground(Color.WHITE); 
        loadRequisitionsToTable();

        JScrollPane scrollPane = new JScrollPane(requisitionTable);
        scrollPane.setBounds(50, 70, 500, 400);
        add(scrollPane);

        // Button panel with Close button
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.setBackground(new Color(255, 140, 0)); 
        closeButton.setForeground(Color.BLACK);
        closeButton.setBounds(200, 500, 200, 40); 
        closeButton.addActionListener(e -> {
            dispose();
            mainMenu.setVisible(true);
        });
        add(closeButton);
    }

    // Load requisitions from the database and display in the table
    private void loadRequisitionsToTable() {
        tableModel.setRowCount(0);  
        List<PurchaseRequisition> requisitions = RequisitionDatabase.getAllRequisitions();
        
        for (PurchaseRequisition requisition : requisitions) {
            tableModel.addRow(new Object[]{
                requisition.getRequisitionId(),
                requisition.getItemCode(),
                requisition.getQuantity(),
                requisition.getSupplierCode(),  
                requisition.getRequiredDate(),  
                requisition.getDescription()
            });
        }
    }
}
