package gui;

import models.Supplier;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionListener;

public class ListOfSuppliersGUI extends JFrame {
    private JTable supplierTable;
    private DefaultTableModel tableModel;
    private static final String FILE_PATH = "suppliers.txt";
    private JFrame mainMenu;

    public ListOfSuppliersGUI(JFrame mainMenu) {
        this.mainMenu = mainMenu;
        // Hide the Main Menu instead of disposing it
        mainMenu.setVisible(false);

        // Set up the frame
        setTitle("List of Suppliers");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK);

        // Title Label
        JLabel titleLabel = new JLabel("List of Suppliers", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(150, 20, 300, 30);
        add(titleLabel);

        // Table Setup
        String[] columnNames = {"Supplier ID", "Supplier Name", "Contact Info"};
        tableModel = new DefaultTableModel(columnNames, 0);
        supplierTable = new JTable(tableModel);
        supplierTable.setFont(new Font("Arial", Font.PLAIN, 14));
        supplierTable.setBackground(new Color(105, 105, 105));
        supplierTable.setForeground(Color.WHITE);
        supplierTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        supplierTable.getTableHeader().setBackground(new Color(255, 140, 0));
        supplierTable.getTableHeader().setForeground(Color.WHITE);

        // Scroll Pane for Table
        JScrollPane scrollPane = new JScrollPane(supplierTable);
        scrollPane.setBounds(50, 70, 500, 400);
        add(scrollPane);

        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.BLACK);
        buttonPanel.setBounds(150, 500, 300, 40);
        buttonPanel.setLayout(new GridLayout(1, 2, 20, 0));

        JButton refreshButton = new JButton("Refresh");
        refreshButton.setFont(new Font("Arial", Font.BOLD, 14));
        refreshButton.setBackground(new Color(11, 136, 255));
        refreshButton.setForeground(Color.BLACK);
        refreshButton.addActionListener(e -> loadSuppliersFromFile());
        buttonPanel.add(refreshButton);

        JButton exitButton = new JButton("Exit");
        exitButton.setFont(new Font("Arial", Font.BOLD, 14));
        exitButton.setBackground(new Color(255, 140, 0));
        exitButton.setForeground(Color.BLACK);
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                closeAndReturnToMainMenu();
            }
        });
        buttonPanel.add(exitButton);

        add(buttonPanel);

        // Load Initial Data
        loadSuppliersFromFile();
    }

    // Loads suppliers from suppliers.txt and display in the table
    private void loadSuppliersFromFile() {
        tableModel.setRowCount(0);  
        List<Supplier> suppliers = readSuppliersFromFile();

        for (Supplier supplier : suppliers) {
            tableModel.addRow(new Object[]{supplier.getSupplierId(), supplier.getSupplierName(), supplier.getContactInfo()});
        }
    }

    // Reads suppliers from suppliers.txt
    private List<Supplier> readSuppliersFromFile() {
        List<Supplier> suppliers = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String supplierId = parts[0];
                    String supplierName = parts[1];
                    String contactInfo = parts[2];
                    suppliers.add(new Supplier(supplierId, supplierName, contactInfo));
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading suppliers.txt: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return suppliers;
    }

    // Closes this window and re-open the main menu
    private void closeAndReturnToMainMenu() {
        dispose(); 
        mainMenu.setVisible(true); 
    }
}
