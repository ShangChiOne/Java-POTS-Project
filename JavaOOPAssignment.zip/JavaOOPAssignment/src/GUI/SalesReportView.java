package gui;

import javax.swing.*;
import models.Item;
import models.ItemDatabase;
import models.SalesReport;
import models.SalesDatabase;
import models.User;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.io.font.constants.StandardFonts;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import java.text.DecimalFormat;

import java.awt.*;
import java.awt.Color;
import java.awt.Font;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;

public class SalesReportView extends JFrame {
    private JComboBox<LocalDate> startDateComboBox;
    private JTextField endDateField;
    private JButton generateButton, exportExcelButton, exportPdfButton, backButton, generatePieChartButton;
    private JTextArea reportArea;
    private JFrame previousPage;
    private User user;
    private Map<String, Integer> currentReportData;

    public SalesReportView(JFrame previousPage, User user) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);

        // Frame Setup
        setTitle("Sales Report");
        setSize(600, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK);

        // Start Date Selector
        JLabel startDateLabel = new JLabel("Start Date:");
        startDateLabel.setFont(new Font("Arial", Font.BOLD, 16));
        startDateLabel.setForeground(Color.WHITE);
        startDateLabel.setBounds(150, 30, 300, 30);
        add(startDateLabel);

        startDateComboBox = new JComboBox<>();
        startDateComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        startDateComboBox.setBackground(new Color(105, 105, 105)); // Darker grey text box
        startDateComboBox.setForeground(Color.WHITE); // White text
        startDateComboBox.setBounds(150, 60, 300, 30);
        populateStartDateComboBox();
        add(startDateComboBox);

        // End Date Input
        JLabel endDateLabel = new JLabel("End Date (YYYY-MM-DD):");
        endDateLabel.setFont(new Font("Arial", Font.BOLD, 16));
        endDateLabel.setForeground(Color.WHITE);
        endDateLabel.setBounds(150, 100, 300, 30);
        add(endDateLabel);

        endDateField = new JTextField();
        endDateField.setFont(new Font("Arial", Font.PLAIN, 14));
        endDateField.setBackground(new Color(105, 105, 105)); // Darker grey text box
        endDateField.setForeground(Color.WHITE); // White text
        endDateField.setBounds(150, 130, 300, 30);
        add(endDateField);

        // Buttons
        generateButton = new JButton("Generate Report");
        generateButton.setFont(new Font("Arial", Font.BOLD, 14));
        generateButton.setBackground(new Color(11, 136, 255)); // Blue button
        generateButton.setForeground(Color.BLACK); // Black text
        generateButton.setBounds(200, 180, 200, 40);
        generateButton.addActionListener(e -> generateReport());
        add(generateButton);

        exportExcelButton = new JButton("Export to Excel");
        exportExcelButton.setFont(new Font("Arial", Font.BOLD, 14));
        exportExcelButton.setBackground(new Color(211, 211, 211)); // Light grey button
        exportExcelButton.setForeground(Color.BLACK); // Black text
        exportExcelButton.setBounds(150, 240, 150, 40);
        exportExcelButton.addActionListener(e -> exportToExcel());
        add(exportExcelButton);

        exportPdfButton = new JButton("Export to PDF");
        exportPdfButton.setFont(new Font("Arial", Font.BOLD, 14));
        exportPdfButton.setBackground(new Color(211, 211, 211)); // Light grey button
        exportPdfButton.setForeground(Color.BLACK); // Black text
        exportPdfButton.setBounds(310, 240, 150, 40);
        exportPdfButton.addActionListener(e -> exportToPdf());
        add(exportPdfButton);

        // Adjusted Back Button
        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0)); // Orange button
        backButton.setForeground(Color.BLACK); // Black text
        backButton.setBounds(200, 580, 200, 40); // Moved down to create space for "Generate Pie Chart"
        backButton.addActionListener(e -> goBack());
        add(backButton);

        // Adjusted Generate Pie Chart Button
        generatePieChartButton = new JButton("Generate Pie Chart");
        generatePieChartButton.setFont(new Font("Arial", Font.BOLD, 14));
        generatePieChartButton.setBackground(new Color(50, 205, 50)); // Orange button
        generatePieChartButton.setForeground(Color.BLACK); // Black text
        generatePieChartButton.setBounds(200, 520, 200, 40); // Moved above the "Back" button
        generatePieChartButton.addActionListener(e -> generatePieChart());
        add(generatePieChartButton);

        // Report Display Area
        reportArea = new JTextArea();
        reportArea.setFont(new Font("Arial", Font.PLAIN, 14));
        reportArea.setBackground(new Color(105, 105, 105)); // Darker grey background
        reportArea.setForeground(Color.WHITE); // White text
        reportArea.setBounds(50, 300, 500, 200);
        reportArea.setEditable(false);
        add(reportArea);

        setVisible(true);
    }

    // Populate start dates from the Sales Database
    private void populateStartDateComboBox() {
        Set<LocalDate> uniqueDates = SalesDatabase.getAllUniqueDates();
        List<LocalDate> sortedDates = new ArrayList<>(uniqueDates);
        sortedDates.sort(LocalDate::compareTo);
        for (LocalDate date : sortedDates) {
            startDateComboBox.addItem(date);
        }
    }

    // Generate the report and display it
    private void generateReport() {
        LocalDate startDate = (LocalDate) startDateComboBox.getSelectedItem();
        String endDateInput = endDateField.getText();

        LocalDate endDate;
        try {
            endDate = LocalDate.parse(endDateInput);
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "Invalid End Date format. Use YYYY-MM-DD.");
            return;
        }

        if (endDate.isBefore(startDate)) {
            JOptionPane.showMessageDialog(this, "End Date must be after Start Date.");
            return;
        }

        currentReportData = SalesReport.generateSalesWithinDateRange(startDate, endDate);
        if (currentReportData == null || currentReportData.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No sales data available for the selected range.");
        } else {
            displayReport();
        }
    }

    // Display the generated report in the text area
    private void displayReport() {
        reportArea.setText("Sales Report:\n");
        for (Map.Entry<String, Integer> entry : currentReportData.entrySet()) {
            Item item = ItemDatabase.getItemByCode(entry.getKey());
            String itemName = (item != null) ? item.getItemName() : "Unknown Item";
            reportArea.append(String.format("Item: %s (Code: %s), Quantity: %d\n", itemName, entry.getKey(), entry.getValue()));
        }
    }

    // Export the report to an Excel file
    private void exportToExcel() {
        if (currentReportData == null || currentReportData.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please generate the report before exporting to Excel.");
            return;
        }

        LocalDate startDate = (LocalDate) startDateComboBox.getSelectedItem();
        String endDateInput = endDateField.getText();

        try {
            LocalDate endDate = LocalDate.parse(endDateInput);

            // Generate a unique filename based on the start date
            String fileName = String.format("SalesReport_%s.xlsx", startDate);

            try (Workbook workbook = new XSSFWorkbook()) {
                Sheet sheet = workbook.createSheet("Sales Report");

                // Add date range to the first row
                Row dateRow = sheet.createRow(0);
                dateRow.createCell(0).setCellValue(String.format("Date: %s to %s", startDate, endDate));

                // Add headers
                Row header = sheet.createRow(1);
                header.createCell(0).setCellValue("Item Code");
                header.createCell(1).setCellValue("Item Name");
                header.createCell(2).setCellValue("Quantity Sold");

                // Add sales data
                int rowIndex = 2;
                for (Map.Entry<String, Integer> entry : currentReportData.entrySet()) {
                    Row row = sheet.createRow(rowIndex++);
                    row.createCell(0).setCellValue(entry.getKey());
                    Item item = ItemDatabase.getItemByCode(entry.getKey());
                    row.createCell(1).setCellValue(item != null ? item.getItemName() : "Unknown Item");
                    row.createCell(2).setCellValue(entry.getValue());
                }

                // Auto-size columns for readability
                sheet.autoSizeColumn(0); 
                sheet.autoSizeColumn(1); 
                sheet.autoSizeColumn(2); 

                // Write to file
                try (FileOutputStream fos = new FileOutputStream(fileName)) {
                    workbook.write(fos);
                }

                JOptionPane.showMessageDialog(this, "Report exported to Excel successfully as " + fileName + "!");
            }
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "Invalid End Date format. Use YYYY-MM-DD.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error exporting to Excel: " + e.getMessage());
        }
    }

    // Export the report to a PDF file
    private void exportToPdf() {
        if (currentReportData == null || currentReportData.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please generate the report before exporting to PDF.");
            return;
        }

        LocalDate startDate = (LocalDate) startDateComboBox.getSelectedItem();
        String endDateInput = endDateField.getText();

        try {
            LocalDate endDate = LocalDate.parse(endDateInput);

            // Generate a unique filename based on the start date
            String fileName = String.format("SalesReport_%s.pdf", startDate);

            PdfWriter writer = new PdfWriter(fileName);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            // Center Title
            PdfFont boldFont = PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD);
            Paragraph title = new Paragraph("Sales Report")
                    .setFont(boldFont)
                    .setFontSize(18)
                    .setTextAlignment(com.itextpdf.layout.properties.TextAlignment.CENTER);
            document.add(title);

            // Add selected date range to the PDF
            Paragraph dateRange = new Paragraph(String.format("Date: %s to %s", startDate, endDate))
                    .setFont(boldFont)
                    .setFontSize(12)
                    .setTextAlignment(com.itextpdf.layout.properties.TextAlignment.CENTER)
                    .setMarginBottom(10);
            document.add(dateRange);

            // Center Table
            Table table = new Table(3)
                    .setWidth(com.itextpdf.layout.properties.UnitValue.createPercentValue(50)) // Set table width to 50% of the page width
                    .setHorizontalAlignment(com.itextpdf.layout.properties.HorizontalAlignment.CENTER); // Center align the table

            Cell header1 = new Cell().add(new Paragraph("Item Code").setFont(boldFont));
            header1.setBackgroundColor(new com.itextpdf.kernel.colors.DeviceRgb(255, 140, 0)); // Set RGB color
            table.addCell(header1);

            Cell header2 = new Cell().add(new Paragraph("Item Name").setFont(boldFont));
            header2.setBackgroundColor(new com.itextpdf.kernel.colors.DeviceRgb(255, 140, 0)); // Set RGB color
            table.addCell(header2);

            Cell header3 = new Cell().add(new Paragraph("Quantity Sold").setFont(boldFont));
            header3.setBackgroundColor(new com.itextpdf.kernel.colors.DeviceRgb(255, 140, 0)); // Set RGB color
            table.addCell(header3);

            for (Map.Entry<String, Integer> entry : currentReportData.entrySet()) {
                String itemCode = entry.getKey();
                Item item = ItemDatabase.getItemByCode(itemCode);
                String itemName = (item != null) ? item.getItemName() : "Unknown Item";

                table.addCell(new Cell().add(new Paragraph(itemCode)));
                table.addCell(new Cell().add(new Paragraph(itemName)));
                table.addCell(new Cell().add(new Paragraph(String.valueOf(entry.getValue()))));
            }

            document.add(table);
            document.close();

            JOptionPane.showMessageDialog(this, "Report exported to PDF successfully as " + fileName + "!");
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "Invalid End Date format. Use YYYY-MM-DD.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error exporting to PDF: " + e.getMessage());
        }
    }
    
    // Generate a pie chart from the report data
    private void generatePieChart() {
        if (currentReportData == null || currentReportData.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please generate the report before creating the pie chart.");
            return;
        }

        DefaultPieDataset dataset = new DefaultPieDataset();
        for (Map.Entry<String, Integer> entry : currentReportData.entrySet()) {
            Item item = ItemDatabase.getItemByCode(entry.getKey());
            String itemName = (item != null) ? item.getItemName() : "Unknown Item";
            dataset.setValue(itemName, entry.getValue());
        }

        JFreeChart pieChart = ChartFactory.createPieChart(
                "Sales Distribution", // Chart title
                dataset,
                true, // Include legend
                true,
                false
        );

        // Set percentage labels
        org.jfree.chart.plot.PiePlot plot = (org.jfree.chart.plot.PiePlot) pieChart.getPlot();
        plot.setLabelGenerator(new StandardPieSectionLabelGenerator(
                "{0}: {1} ({2})", // {0}=Key, {1}=Value, {2}=Percentage
                new DecimalFormat("0"), // Format for absolute value
                new DecimalFormat("0.0%") // Format for percentage
        ));

        JFrame chartFrame = new JFrame("Sales Pie Chart");
        ChartPanel chartPanel = new ChartPanel(pieChart);
        chartPanel.setPreferredSize(new Dimension(600, 400));
        chartFrame.add(chartPanel);
        chartFrame.pack();
        chartFrame.setLocationRelativeTo(this);
        chartFrame.setVisible(true);
    }

    // Return to the previous page
    private void goBack() {
        this.dispose();
        previousPage.setVisible(true);
    }
}