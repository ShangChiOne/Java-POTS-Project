package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import models.Item;
import models.User;
import models.Supplier;
import models.ItemDatabase;
import models.SupplierDatabase;
import gui.EditItemEntryForm;


public class ItemEntryForm extends JFrame {
    private JTextField itemCodeField;
    private JTextField itemNameField;
    private JComboBox<String> supplierIdComboBox;
    private JButton addButton;
    private JButton clearButton;
    private User user;
    private JFrame previousPage;

    // Frame setup
    public ItemEntryForm(JFrame previousPage, User user) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);
        this.user = user;
        setTitle("Item Entry Form");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK);

        // Item Code Label and Field
        JLabel itemCodeLabel = new JLabel("Item Code:");
        itemCodeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        itemCodeLabel.setForeground(Color.WHITE);
        itemCodeLabel.setBounds(200, 120, 200, 30);
        add(itemCodeLabel);

        itemCodeField = new JTextField();
        itemCodeField.setFont(new Font("Arial", Font.PLAIN, 14));
        itemCodeField.setBackground(new Color(105, 105, 105));
        itemCodeField.setForeground(Color.WHITE);
        itemCodeField.setBounds(200, 160, 200, 30);
        add(itemCodeField);

        // Item Name Label and Field
        JLabel itemNameLabel = new JLabel("Item Name:");
        itemNameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        itemNameLabel.setForeground(Color.WHITE);
        itemNameLabel.setBounds(200, 200, 200, 30);
        add(itemNameLabel);

        itemNameField = new JTextField();
        itemNameField.setFont(new Font("Arial", Font.PLAIN, 14));
        itemNameField.setBackground(new Color(105, 105, 105));
        itemNameField.setForeground(Color.WHITE);
        itemNameField.setBounds(200, 240, 200, 30);
        add(itemNameField);

        // Supplier ID Label and ComboBox
        JLabel supplierIdLabel = new JLabel("Supplier ID:");
        supplierIdLabel.setFont(new Font("Arial", Font.BOLD, 16));
        supplierIdLabel.setForeground(Color.WHITE);
        supplierIdLabel.setBounds(200, 280, 200, 30);
        add(supplierIdLabel);

        supplierIdComboBox = new JComboBox<>();
        supplierIdComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        supplierIdComboBox.setBackground(new Color(105, 105, 105));
        supplierIdComboBox.setForeground(Color.WHITE);
        supplierIdComboBox.setBounds(200, 320, 200, 30);
        populateSupplierIdComboBox();
        add(supplierIdComboBox);

        // Add Item Button
        addButton = new JButton("Add Item");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setBackground(new Color(11, 136, 255));
        addButton.setBounds(150, 380, 100, 40);
        addButton.addActionListener(e -> addItem());
        add(addButton);

        // Clear Form Button
        clearButton = new JButton("Clear");
        clearButton.setFont(new Font("Arial", Font.BOLD, 14));
        clearButton.setBackground(new Color(211, 211, 211));
        clearButton.setBounds(260, 380, 100, 40);
        clearButton.addActionListener(e -> clearForm());
        add(clearButton);

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0));
        backButton.setBounds(370, 380, 100, 40);
        backButton.addActionListener(e -> goBack());
        add(backButton);

        // Manage Items Button
        JButton manageItemsButton = new JButton("Manage Items");
        manageItemsButton.setFont(new Font("Arial", Font.BOLD, 14));
        manageItemsButton.setBackground(new Color(50, 205, 50)); // Green button
        manageItemsButton.setBounds(200, 440, 200, 40);
        manageItemsButton.addActionListener(e -> openEditItemEntryForm());
        add(manageItemsButton);
    }

    // Populate supplier dropdown with available supplier IDs
    private void populateSupplierIdComboBox() {
        supplierIdComboBox.removeAllItems();
        for (Supplier supplier : SupplierDatabase.getAllSuppliers()) {
            supplierIdComboBox.addItem(supplier.getSupplierId());
        }
    }

    // Add a new item to the database
    private void addItem() {
        String itemCode = itemCodeField.getText();
        String itemName = itemNameField.getText();
        String supplierId = (String) supplierIdComboBox.getSelectedItem();

        if (itemCode.isEmpty() || itemName.isEmpty() || supplierId == null || supplierId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
        } else if (ItemDatabase.isItemCodeDuplicate(itemCode)) {
            JOptionPane.showMessageDialog(this, "Item Code already exists. Please enter a unique code.");
        } else if (ItemDatabase.isItemNameDuplicate(itemName)) {
            JOptionPane.showMessageDialog(this, "Item Name already exists. Please enter a unique name.");
        } else {
            Item item = new Item(itemCode, itemName, supplierId);
            ItemDatabase.addItem(item);
            JOptionPane.showMessageDialog(this, "Item added successfully!");
            clearForm();
        }
    }

    // Clear all form fields
    private void clearForm() {
        itemCodeField.setText("");
        itemNameField.setText("");
        supplierIdComboBox.setSelectedIndex(-1);
    }

    // Navigate back to the previous page
    private void goBack() {
        this.dispose();
        previousPage.setVisible(true);
    }

    // Open the Edit Item Entry form
    private void openEditItemEntryForm() {
        EditItemEntryForm editItemForm = new EditItemEntryForm(this, user);
        editItemForm.setVisible(true);
        this.setVisible(false);
    }
}
