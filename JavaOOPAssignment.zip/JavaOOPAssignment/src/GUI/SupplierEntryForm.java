package gui;

import javax.swing.*;
import java.awt.*;
import models.Supplier;
import models.User;
import models.SupplierDatabase;

public class SupplierEntryForm extends JFrame {
    private JTextField supplierIdField;
    private JTextField supplierNameField;
    private JTextField contactInfoField;
    private JButton addButton;
    private JButton clearButton;
    private User user;
    private JFrame previousPage;

    public SupplierEntryForm(JFrame previousPage, User user) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);
        this.user = user;
        
        // Frame Setup
        setTitle("Supplier Entry Form");
        setSize(600, 600);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        int baseY = 80; 
        int spacing = 40; 

        // Supplier ID Label and Field
        JLabel supplierIdLabel = new JLabel("Supplier ID:");
        supplierIdLabel.setFont(new Font("Arial", Font.BOLD, 16));
        supplierIdLabel.setForeground(Color.WHITE);
        supplierIdLabel.setBounds(200, baseY, 200, 30);   
        add(supplierIdLabel);

        supplierIdField = new JTextField();
        supplierIdField.setFont(new Font("Arial", Font.PLAIN, 14));
        supplierIdField.setBackground(new Color(105, 105, 105)); 
        supplierIdField.setForeground(Color.WHITE);
        supplierIdField.setBounds(200, baseY + spacing, 200, 30); 
        add(supplierIdField);

        // Supplier Name Label and Field
        JLabel supplierNameLabel = new JLabel("Supplier Name:");
        supplierNameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        supplierNameLabel.setForeground(Color.WHITE);
        supplierNameLabel.setBounds(200, baseY + spacing * 2, 200, 30); 
        add(supplierNameLabel);

        supplierNameField = new JTextField();
        supplierNameField.setFont(new Font("Arial", Font.PLAIN, 14));
        supplierNameField.setBackground(new Color(105, 105, 105)); 
        supplierNameField.setForeground(Color.WHITE);
        supplierNameField.setBounds(200, baseY + spacing * 3, 200, 30); 
        add(supplierNameField);

        // Contact Info Label and Field
        JLabel contactInfoLabel = new JLabel("Contact Info (+60):");
        contactInfoLabel.setFont(new Font("Arial", Font.BOLD, 16));
        contactInfoLabel.setForeground(Color.WHITE);
        contactInfoLabel.setBounds(200, baseY + spacing * 4, 200, 30); 
        add(contactInfoLabel);

        contactInfoField = new JTextField();
        contactInfoField.setFont(new Font("Arial", Font.PLAIN, 14));
        contactInfoField.setBackground(new Color(105, 105, 105)); 
        contactInfoField.setForeground(Color.WHITE);
        contactInfoField.setBounds(200, baseY + spacing * 5, 200, 30); 
        add(contactInfoField);

        // Add Supplier Button
        addButton = new JButton("Add Supplier");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setBackground(new Color(11, 136, 255)); 
        addButton.setBounds(150, baseY + spacing * 6 + 20, 150, 40); 
        addButton.addActionListener(e -> addSupplier());
        add(addButton);

        // Clear Form Button
        clearButton = new JButton("Clear");
        clearButton.setFont(new Font("Arial", Font.BOLD, 14));
        clearButton.setBackground(new Color(211, 211, 211)); 
        clearButton.setBounds(310, baseY + spacing * 6 + 20, 150, 40); 
        clearButton.addActionListener(e -> clearForm());
        add(clearButton);

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0)); 
        backButton.setBounds(200, baseY + spacing * 7 + 40, 200, 40); 
        backButton.addActionListener(e -> goBack());
        add(backButton);

        // Manage Supplier Button
        JButton manageSupplierButton = new JButton("Manage Supplier");
        manageSupplierButton.setFont(new Font("Arial", Font.BOLD, 14));
        manageSupplierButton.setBackground(new Color(50, 205, 50)); 
        manageSupplierButton.setBounds(200, baseY + spacing * 8 + 60, 200, 40); 
        manageSupplierButton.addActionListener(e -> openEditSupplierEntryForm());
        add(manageSupplierButton);
    }

    // Open the Edit Supplier Entry Form
    private void openEditSupplierEntryForm() {
        new EditSupplierEntryForm(this, user).setVisible(true); 
        this.setVisible(false); 
    }

    // Add a new supplier
    private void addSupplier() {
        String supplierId = supplierIdField.getText();
        String supplierName = supplierNameField.getText();
        String contactInfo = contactInfoField.getText();

        if (supplierId.isEmpty() || supplierName.isEmpty() || contactInfo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
        } else if (!isValidPhoneNumber(contactInfo)) {
            JOptionPane.showMessageDialog(this, "Invalid contact info. Please enter a valid phone number.");
        } else if (SupplierDatabase.isSupplierIdDuplicate(supplierId)) {
            JOptionPane.showMessageDialog(this, "Supplier ID already exists. Please enter a unique Supplier ID.");
        } else {
            Supplier supplier = new Supplier(supplierId, supplierName, contactInfo);
            SupplierDatabase.addSupplier(supplier);
            JOptionPane.showMessageDialog(this, "Supplier added successfully!");
            clearForm();
        }
    }

    // Validate phone numbers
    private boolean isValidPhoneNumber(String phoneNumber) {
        // Matches optional "+" at the start, followed by 10 to 15 digits
        return phoneNumber.matches("\\+?\\d{10,15}");
    }

    // Clear the form fields
    private void clearForm() {
        supplierIdField.setText("");
        supplierNameField.setText("");
        contactInfoField.setText("");
    }

    // Go back to the previous page
    private void goBack() {
        this.dispose(); 
        previousPage.setVisible(true); 
    }
}
