// gui/EditItemEntryForm.java
package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import models.Item;
import models.User;
import models.ItemDatabase;
import models.SupplierDatabase;

public class EditItemEntryForm extends JFrame {
    private JComboBox<String> itemCodeComboBox;
    private JTextField itemNameField;
    private JComboBox<String> supplierIdComboBox;
    private JButton editButton;
    private JButton deleteButton;
    private User user;
    private JFrame previousPage;

    public EditItemEntryForm(JFrame previousPage, User user) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);
        this.user = user;
        setTitle("Edit Item Entry Form");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK);

        // Item Code Label and ComboBox
        JLabel itemCodeLabel = new JLabel("Item Code:");
        itemCodeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        itemCodeLabel.setForeground(Color.WHITE);
        itemCodeLabel.setBounds(200, 120, 200, 30);
        add(itemCodeLabel);

        itemCodeComboBox = new JComboBox<>();
        itemCodeComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        itemCodeComboBox.setBackground(new Color(105, 105, 105));
        itemCodeComboBox.setForeground(Color.WHITE);
        itemCodeComboBox.setBounds(200, 160, 200, 30);
        populateItemCodeComboBox(); 
        itemCodeComboBox.addActionListener(e -> loadItemDetails()); 
        add(itemCodeComboBox);

        // Item Name Label and Field
        JLabel itemNameLabel = new JLabel("Item Name:");
        itemNameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        itemNameLabel.setForeground(Color.WHITE);
        itemNameLabel.setBounds(200, 200, 200, 30);
        add(itemNameLabel);

        itemNameField = new JTextField();
        itemNameField.setFont(new Font("Arial", Font.PLAIN, 14));
        itemNameField.setBackground(new Color(105, 105, 105));
        itemNameField.setForeground(Color.WHITE);
        itemNameField.setBounds(200, 240, 200, 30);
        add(itemNameField);

        // Supplier ID Label and ComboBox
        JLabel supplierIdLabel = new JLabel("Supplier ID:");
        supplierIdLabel.setFont(new Font("Arial", Font.BOLD, 16));
        supplierIdLabel.setForeground(Color.WHITE);
        supplierIdLabel.setBounds(200, 280, 200, 30);
        add(supplierIdLabel);

        supplierIdComboBox = new JComboBox<>();
        supplierIdComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        supplierIdComboBox.setBackground(new Color(105, 105, 105));
        supplierIdComboBox.setForeground(Color.WHITE);
        supplierIdComboBox.setBounds(200, 320, 200, 30);
        populateSupplierIdComboBox(); 
        add(supplierIdComboBox);

        // Edit Item Button
        editButton = new JButton("Edit Item");
        editButton.setFont(new Font("Arial", Font.BOLD, 14));
        editButton.setBackground(new Color(11, 136, 255));
        editButton.setBounds(80, 380, 120, 40);
        editButton.addActionListener(e -> editItem());
        add(editButton);

        // Delete Item Button
        deleteButton = new JButton("Delete Item");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteButton.setBackground(new Color(255, 69, 0));
        deleteButton.setBounds(240, 380, 120, 40);
        deleteButton.addActionListener(e -> deleteItem());
        add(deleteButton);

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0));
        backButton.setBounds(400, 380, 120, 40);
        backButton.addActionListener(e -> goBack());
        add(backButton);
    }

    // Loads  item codes into the ComboBox
    private void populateItemCodeComboBox() {
        itemCodeComboBox.removeAllItems();
        for (Item item : ItemDatabase.getAllItems()) {
            itemCodeComboBox.addItem(item.getItemCode());
        }
    }
    
    // Loads supplier IDs into the ComboBox
    private void populateSupplierIdComboBox() {
        supplierIdComboBox.removeAllItems();
        for (String supplierId : SupplierDatabase.getAllSupplierIds()) {
            supplierIdComboBox.addItem(supplierId);
        }
    }

    // Fills form fields with details of the selected item
    private void loadItemDetails() {
        String selectedCode = (String) itemCodeComboBox.getSelectedItem();
        if (selectedCode != null) {
            Item item = ItemDatabase.getItemByCode(selectedCode);
            if (item != null) {
                itemNameField.setText(item.getItemName());
                supplierIdComboBox.setSelectedItem(item.getSupplierId());
            }
        }
    }

    // Updates item details in the database
    private void editItem() {
        String itemCode = (String) itemCodeComboBox.getSelectedItem();
        String itemName = itemNameField.getText();
        String supplierId = (String) supplierIdComboBox.getSelectedItem();

        if (itemCode != null && itemName != null && supplierId != null) {
            ItemDatabase.updateItem(itemCode, itemName, supplierId); 
            JOptionPane.showMessageDialog(this, "Item updated successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
        }
    }

    // Deletes the selected item from the database
    private void deleteItem() {
        String itemCode = (String) itemCodeComboBox.getSelectedItem();
        if (itemCode != null) {
            ItemDatabase.deleteItem(itemCode);
            JOptionPane.showMessageDialog(this, "Item deleted successfully!");
            clearForm();
            populateItemCodeComboBox(); 
        } else {
            JOptionPane.showMessageDialog(this, "Please select an item to delete.");
        }
    }

    // Clears form fields
    private void clearForm() {
        itemCodeComboBox.setSelectedIndex(-1);
        itemNameField.setText("");
        supplierIdComboBox.setSelectedIndex(-1);
    }

    // Returns to the previous page
    private void goBack() {
        this.dispose();
        previousPage.setVisible(true);
    }
}
