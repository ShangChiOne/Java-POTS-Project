package gui;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import models.SalesEntry;
import models.SalesDatabase;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.UUID;

public class SalesEntryForm extends JFrame {
    private JComboBox<String> itemComboBox;
    private JTextField dateField;
    private JTextField quantityField;
    private JButton addButton;
    private JFrame previousPage;

    public SalesEntryForm(JFrame previousPage) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);

        // Frame setup
        setTitle("Daily Sales Entry");
        setSize(600, 600); 
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        // Item selection dropdown
        JLabel itemLabel = new JLabel("Select Item:");
        itemLabel.setFont(new Font("Arial", Font.BOLD, 16));
        itemLabel.setForeground(Color.WHITE);
        itemLabel.setBounds(200, 100, 200, 30); 
        add(itemLabel);

        itemComboBox = new JComboBox<>();
        itemComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        itemComboBox.setBackground(new Color(105, 105, 105)); 
        itemComboBox.setForeground(Color.WHITE); 
        itemComboBox.setBounds(200, 140, 200, 30);
        populateItemComboBox();
        add(itemComboBox);

        // Date field
        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
        dateLabel.setFont(new Font("Arial", Font.BOLD, 16));
        dateLabel.setForeground(Color.WHITE);
        dateLabel.setBounds(200, 180, 200, 30);
        add(dateLabel);

        dateField = new JTextField(LocalDate.now().toString());
        dateField.setFont(new Font("Arial", Font.PLAIN, 14));
        dateField.setBackground(new Color(105, 105, 105)); 
        dateField.setForeground(Color.WHITE); 
        dateField.setBounds(200, 220, 200, 30);
        add(dateField);

        // Quantity field
        JLabel quantityLabel = new JLabel("Quantity Sold:");
        quantityLabel.setFont(new Font("Arial", Font.BOLD, 16));
        quantityLabel.setForeground(Color.WHITE);
        quantityLabel.setBounds(200, 260, 200, 30);
        add(quantityLabel);

        quantityField = new JTextField();
        quantityField.setFont(new Font("Arial", Font.PLAIN, 14));
        quantityField.setBackground(new Color(105, 105, 105)); 
        quantityField.setForeground(Color.WHITE); 
        quantityField.setBounds(200, 300, 200, 30);
        add(quantityField);

        // Add Entry button
        addButton = new JButton("Add Entry");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setBackground(new Color(11, 136, 255)); 
        addButton.setBounds(150, 360, 140, 40);
        addButton.addActionListener(e -> addSalesEntry());
        add(addButton);

        // Back button
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0)); 
        backButton.setBounds(310, 360, 140, 40);
        backButton.addActionListener(e -> goBack());
        add(backButton);
        
        // Edit Sales button
        JButton editSalesButton = new JButton("Edit Sales");
        editSalesButton.setFont(new Font("Arial", Font.BOLD, 14));
        editSalesButton.setBackground(new Color(50, 205, 50)); 
        editSalesButton.setBounds(200, 420, 200, 40);
        editSalesButton.addActionListener(e -> openEditSalesEntryForm());
        add(editSalesButton);

    }

    // Populate the item dropdown with items from the stock file
    private void populateItemComboBox() {
        itemComboBox.removeAllItems(); 
        List<String[]> stockLevels = readStockLevels(); 
        for (String[] stock : stockLevels) {
            String itemCode = stock[0]; 
            itemComboBox.addItem(itemCode); 
        }
        if (itemComboBox.getItemCount() == 0) {
            JOptionPane.showMessageDialog(this, 
                "No items available in stock. Please update the stock levels first.", 
                "Warning", 
                JOptionPane.WARNING_MESSAGE);
        }
    }
    
    // Open the Edit Sales Entry Form
    private void openEditSalesEntryForm() {
        new EditSalesEntryForm(this).setVisible(true);
    }

    // Add a new sales entry to the database
    private void addSalesEntry() {
        String itemCode = (String) itemComboBox.getSelectedItem();
        LocalDate date;
        int quantity;

        try {
            date = LocalDate.parse(dateField.getText());
            quantity = Integer.parseInt(quantityField.getText());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid date and quantity.");
            return;
        }

        // Deduct stock before adding the sale
            if (!deductStockQuantity(itemCode, quantity)) {
                return; // If stock deduction fails, stop the process
            }

            // Generate a random tracker ID
            String trackerID = "SALE-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

            // Add the sales entry
            SalesEntry entry = new SalesEntry(trackerID, itemCode, date, quantity);
            SalesDatabase.addSalesEntry(entry);

            JOptionPane.showMessageDialog(this, "Sales entry added with Tracker ID: " + trackerID);
            quantityField.setText(""); 
        }

    // Read stock levels from the StockLevels.txt file
    private List<String[]> readStockLevels() {
        List<String[]> stockData = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("StockLevels.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stockData.add(line.split(",")); 
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, 
                "Error reading stock levels: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
        return stockData;
    }
  
    // Deduct stock quantity when a sale is made
    private boolean deductStockQuantity(String itemCode, int quantitySold) {
    List<String[]> stockLevels = readStockLevels(); 
    boolean stockUpdated = false;

    // Update the stock quantity in memory
    for (String[] stock : stockLevels) {
        if (stock[0].equals(itemCode)) { 
            int currentStock = Integer.parseInt(stock[2]);
            if (currentStock < quantitySold) { 
                JOptionPane.showMessageDialog(this,
                    "Insufficient stock! Available: " + currentStock,
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
            stock[2] = String.valueOf(currentStock - quantitySold); 
            stockUpdated = true;
            break;
        }
    }
    
    // Save updated stock levels back to the file
    if (stockUpdated) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("StockLevels.txt"))) {
            for (String[] stock : stockLevels) {
                writer.write(String.join(",", stock));
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                "Error updating stock levels: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    return stockUpdated;
}

    // Return to the previous page
    private void goBack() {
        this.dispose();
        previousPage.setVisible(true);
    }
}
