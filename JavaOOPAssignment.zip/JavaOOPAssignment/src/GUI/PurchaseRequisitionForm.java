package gui;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import models.Item;
import models.ItemDatabase;
import models.PurchaseRequisition;
import models.RequisitionDatabase;
import models.User;

public class PurchaseRequisitionForm extends JFrame {
    private JComboBox<String> itemCodeComboBox; 
    private JTextField quantityField;
    private JTextField requiredDateField;  
    private JTextField supplierCodeField;  
    private JTextArea descriptionArea;
    private JButton addButton;
    private JButton clearButton;
    private JButton backButton;
    private JFrame previousPage;
    private User user;

    public PurchaseRequisitionForm(JFrame previousPage, User user) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);
        this.user = user;
        
        // Frame Setup
        setTitle("Purchase Requisition Form");
        setSize(600, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK);

        // Item Code Dropdown
        JLabel itemCodeLabel = new JLabel("Item Code:");
        itemCodeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        itemCodeLabel.setForeground(Color.WHITE);
        itemCodeLabel.setBounds(150, 40, 200, 30);
        add(itemCodeLabel);

        itemCodeComboBox = new JComboBox<>();
        itemCodeComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        itemCodeComboBox.setBackground(new Color(105, 105, 105));
        itemCodeComboBox.setForeground(Color.WHITE);
        itemCodeComboBox.setBounds(150, 70, 300, 30);
        add(itemCodeComboBox);

        // Load item codes from ItemDatabase into the JComboBox
        loadItemCodes();

        // Add listener to update supplier code when item code changes
        itemCodeComboBox.addActionListener(e -> updateSupplierCode());

        // Quantity
        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setFont(new Font("Arial", Font.BOLD, 16));
        quantityLabel.setForeground(Color.WHITE);
        quantityLabel.setBounds(150, 110, 200, 30);
        add(quantityLabel);

        quantityField = new JTextField();
        quantityField.setFont(new Font("Arial", Font.PLAIN, 14));
        quantityField.setBackground(new Color(105, 105, 105));
        quantityField.setForeground(Color.WHITE);
        quantityField.setBounds(150, 140, 300, 30);
        add(quantityField);

        // Required Date
        JLabel requiredDateLabel = new JLabel("Required Date (YYYY-MM-DD):");
        requiredDateLabel.setFont(new Font("Arial", Font.BOLD, 16));
        requiredDateLabel.setForeground(Color.WHITE);
        requiredDateLabel.setBounds(150, 180, 300, 30);
        add(requiredDateLabel);

        requiredDateField = new JTextField();
        requiredDateField.setFont(new Font("Arial", Font.PLAIN, 14));
        requiredDateField.setBackground(new Color(105, 105, 105));
        requiredDateField.setForeground(Color.WHITE);
        requiredDateField.setBounds(150, 210, 300, 30);
        add(requiredDateField);

        // Supplier Code (Auto-filled)
        JLabel supplierCodeLabel = new JLabel("Supplier Code:");
        supplierCodeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        supplierCodeLabel.setForeground(Color.WHITE);
        supplierCodeLabel.setBounds(150, 250, 200, 30);
        add(supplierCodeLabel);

        supplierCodeField = new JTextField();
        supplierCodeField.setFont(new Font("Arial", Font.PLAIN, 14));
        supplierCodeField.setBackground(new Color(105, 105, 105));
        supplierCodeField.setForeground(Color.WHITE);
        supplierCodeField.setBounds(150, 280, 300, 30);
        supplierCodeField.setEditable(false);  
        add(supplierCodeField);

        // Description
        JLabel descriptionLabel = new JLabel("Description:");
        descriptionLabel.setFont(new Font("Arial", Font.BOLD, 16));
        descriptionLabel.setForeground(Color.WHITE);
        descriptionLabel.setBounds(150, 320, 200, 30);
        add(descriptionLabel);

        descriptionArea = new JTextArea();
        descriptionArea.setFont(new Font("Arial", Font.PLAIN, 14));
        descriptionArea.setBackground(new Color(105, 105, 105));
        descriptionArea.setForeground(Color.WHITE);
        descriptionArea.setBounds(150, 350, 300, 60);
        add(descriptionArea);

        // Buttons
        addButton = new JButton("Add Requisition");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setBackground(new Color(11, 136, 255));
        addButton.setBounds(150, 430, 150, 40);
        addButton.addActionListener(e -> addRequisition());
        add(addButton);

        clearButton = new JButton("Clear");
        clearButton.setFont(new Font("Arial", Font.BOLD, 14));
        clearButton.setBackground(new Color(211, 211, 211));
        clearButton.setBounds(310, 430, 140, 40);
        clearButton.addActionListener(e -> clearForm());
        add(clearButton);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0));
        backButton.setBounds(230, 490, 140, 40);
        backButton.addActionListener(e -> goBack());
        add(backButton);
    }

    // Load all item codes from the database into the dropdown
    private void loadItemCodes() {
        List<Item> items = ItemDatabase.getAllItems();
        for (Item item : items) {
            itemCodeComboBox.addItem(item.getItemCode());
        }
    }

    // Automatically update the supplier code field based on the selected item
    private void updateSupplierCode() {
        String selectedItemCode = (String) itemCodeComboBox.getSelectedItem();
        if (selectedItemCode != null) {
            Item selectedItem = ItemDatabase.getItemByCode(selectedItemCode);
            if (selectedItem != null) {
                supplierCodeField.setText(selectedItem.getSupplierId());
            } else {
                supplierCodeField.setText("");
            }
        }
    }

    // Add a new requisition to the database
    private void addRequisition() {
        String itemCode = (String) itemCodeComboBox.getSelectedItem();
        int quantity;
        LocalDate requiredDate;

        try {
            quantity = Integer.parseInt(quantityField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantity must be a number.");
            return;
        }

        try {
            requiredDate = LocalDate.parse(requiredDateField.getText());
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Use YYYY-MM-DD.");
            return;
        }

        String supplierCode = supplierCodeField.getText();
        String description = descriptionArea.getText();

        if (itemCode.isEmpty() || supplierCode.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields.");
        } else {
            String createdBy = user.getUsername();
            PurchaseRequisition requisition = new PurchaseRequisition(itemCode, quantity, supplierCode, requiredDate, description, createdBy);

            // Check if the requisition is a duplicate
            for (PurchaseRequisition existing : RequisitionDatabase.getAllRequisitions()) {
                if (existing.getItemCode().equalsIgnoreCase(itemCode)) {
                    JOptionPane.showMessageDialog(this, "A requisition for this item already exists.");
                    return; // Stop if duplicate is found
                }
            }

            // Add the requisition if no duplicates are found
            RequisitionDatabase.addRequisition(requisition, createdBy);
            JOptionPane.showMessageDialog(this, "Requisition added successfully!");
            clearForm();
        }
    }

    // Clear all input fields
    private void clearForm() {
        itemCodeComboBox.setSelectedIndex(-1);  
        quantityField.setText("");
        requiredDateField.setText("");  
        supplierCodeField.setText("");
        descriptionArea.setText("");
    }

    // Navigate back to the previous page
    private void goBack() {
        this.dispose();
        previousPage.setVisible(true);
    }
}
