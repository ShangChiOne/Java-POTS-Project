package gui;

import javax.swing.*;
import models.Payment;
import models.PaymentDatabase;

import java.awt.*;
import java.util.List;

public class PaymentHistoryView extends JFrame {
    private JTable paymentTable;
    private JButton backButton;
    private JFrame previousPage;

    // Frame Setup
    public PaymentHistoryView(JFrame previousPage) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);
        setTitle("Payment History");
        setSize(600, 600);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        // Title label
        JLabel titleLabel = new JLabel("Payment History", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(150, 10, 300, 30); 
        add(titleLabel);

        // Load payments and create table
        String[] columnNames = {"Payment ID", "PO ID", "Amount", "Date", "Status"};
        List<Payment> payments = PaymentDatabase.getAllPayments();
        String[][] data = new String[payments.size()][5];

        for (int i = 0; i < payments.size(); i++) {
            Payment payment = payments.get(i);
            data[i][0] = payment.getPaymentId();
            data[i][1] = payment.getPurchaseOrderId();
            data[i][2] = String.valueOf(payment.getAmount());
            data[i][3] = payment.getPaymentDate().toString();
            data[i][4] = payment.isPaid() ? "Completed" : "Pending";
        }

        paymentTable = new JTable(data, columnNames);
        paymentTable.setFont(new Font("Arial", Font.PLAIN, 14));
        paymentTable.setBackground(new Color(105, 105, 105)); 
        paymentTable.setForeground(Color.WHITE); 
        paymentTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        paymentTable.getTableHeader().setBackground(new Color(255, 140, 0)); 
        paymentTable.getTableHeader().setForeground(Color.WHITE); 

        JScrollPane scrollPane = new JScrollPane(paymentTable);
        scrollPane.setBounds(50, 60, 500, 400); 
        add(scrollPane);

        // Back Button
        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0)); 
        backButton.setForeground(Color.BLACK);
        backButton.setBounds(200, 480, 200, 40); 
        backButton.addActionListener(e -> {
            dispose();
            previousPage.setVisible(true);
        });
        add(backButton);
    }
}
