package gui;

import models.PurchaseOrder;
import models.PurchaseOrderDatabase;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ViewPurchaseOrderList extends JFrame {
    private JTable purchaseOrderTable;
    private DefaultTableModel tableModel;
    private JFrame mainMenu;

    public ViewPurchaseOrderList(JFrame mainMenu) {
        this.mainMenu = mainMenu;
        mainMenu.setVisible(false);

        // Set up the frame
        setTitle("List of Purchase Orders");
        setSize(700, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); // Black background

        // Title label
        JLabel titleLabel = new JLabel("Purchase Orders", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(200, 10, 300, 30); // Moved up slightly for centering
        add(titleLabel);

        // Table setup
        String[] columnNames = {"Order ID", "Requisition ID", "Item Code", "Quantity", "Supplier ID", "Status", "Rejection Reason"};
        tableModel = new DefaultTableModel(columnNames, 0);
        purchaseOrderTable = new JTable(tableModel);
        purchaseOrderTable.setFont(new Font("Arial", Font.PLAIN, 14));
        purchaseOrderTable.setBackground(new Color(105, 105, 105)); // Darker grey background
        purchaseOrderTable.setForeground(Color.WHITE); // White text
        purchaseOrderTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        purchaseOrderTable.getTableHeader().setBackground(new Color(255, 140, 0)); // Orange header
        purchaseOrderTable.getTableHeader().setForeground(Color.WHITE); // White text for header
        loadPurchaseOrdersToTable();

        JScrollPane scrollPane = new JScrollPane(purchaseOrderTable);
        scrollPane.setBounds(50, 60, 600, 400); // Moved up slightly for centering
        add(scrollPane);

        // Button panel with Close button
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.setBackground(new Color(255, 140, 0)); // Orange button
        closeButton.setForeground(Color.BLACK);
        closeButton.setBounds(250, 480, 200, 40); // Moved up slightly for centering
        closeButton.addActionListener(e -> {
            dispose();
            mainMenu.setVisible(true);
        });
        add(closeButton);
    }

    // Loads purchase orders from the database and display them in the table
    private void loadPurchaseOrdersToTable() {
        tableModel.setRowCount(0);  // Clear existing rows
        List<PurchaseOrder> purchaseOrders = PurchaseOrderDatabase.getAllPurchaseOrders();

        for (PurchaseOrder order : purchaseOrders) {
            String status = order.isApproved() ? "Approved" : (order.getRejectionReason().isEmpty() ? "Pending" : "Rejected");
            tableModel.addRow(new Object[]{
                order.getPurchaseOrderId(),
                order.getRequisitionId(),
                order.getItemCode(),
                order.getQuantity(),
                order.getSupplierId(),
                status,
                order.getRejectionReason()
            });
        }
    }
}
