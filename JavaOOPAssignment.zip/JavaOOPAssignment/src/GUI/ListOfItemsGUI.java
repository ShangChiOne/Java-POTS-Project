package gui;

import models.Item;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionListener;


public class ListOfItemsGUI extends JFrame {
    private JTable itemTable;
    private DefaultTableModel tableModel;
    private static final String FILE_PATH = "items.txt";
    private JFrame mainMenu; 

    public ListOfItemsGUI(JFrame mainMenu) {
        this.mainMenu = mainMenu;
        // Hide the Main Menu instead of disposing it
        mainMenu.setVisible(false);
        
        // Set up the frame
        setTitle("List of Items");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK);

        // Title Label
        JLabel titleLabel = new JLabel("List of Items", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(150, 20, 300, 30);
        add(titleLabel);

        // Table Setup
        String[] columnNames = {"Item Code", "Item Name", "Supplier ID"};
        tableModel = new DefaultTableModel(columnNames, 0);
        itemTable = new JTable(tableModel);
        itemTable.setFont(new Font("Arial", Font.PLAIN, 14));
        itemTable.setBackground(new Color(105, 105, 105));
        itemTable.setForeground(Color.WHITE);
        itemTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        itemTable.getTableHeader().setBackground(new Color(255, 140, 0));
        itemTable.getTableHeader().setForeground(Color.WHITE);

        // Scroll Pane for Table
        JScrollPane scrollPane = new JScrollPane(itemTable);
        scrollPane.setBounds(50, 70, 500, 400);
        add(scrollPane);

        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.BLACK);
        buttonPanel.setBounds(150, 500, 300, 40);
        buttonPanel.setLayout(new GridLayout(1, 2, 20, 0));

        JButton refreshButton = new JButton("Refresh");
        refreshButton.setFont(new Font("Arial", Font.BOLD, 14));
        refreshButton.setBackground(new Color(11, 136, 255));
        refreshButton.setForeground(Color.BLACK);
        refreshButton.addActionListener(e -> loadItemsFromFile());
        buttonPanel.add(refreshButton);

        JButton exitButton = new JButton("Exit");
        exitButton.setFont(new Font("Arial", Font.BOLD, 14));
        exitButton.setBackground(new Color(255, 140, 0));
        exitButton.setForeground(Color.BLACK);
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                closeAndReturnToMainMenu();
            }
        });
        buttonPanel.add(exitButton);

        add(buttonPanel);

        // Load Initial Data
        loadItemsFromFile();
    }

    //  Loads items from items.txt and display in the table
    private void loadItemsFromFile() {
        tableModel.setRowCount(0);  
        List<Item> items = readItemsFromFile();

        for (Item item : items) {
            tableModel.addRow(new Object[]{item.getItemCode(), item.getItemName(), item.getSupplierId()});
        }
    }

    // Reads items from items.txt
    private List<Item> readItemsFromFile() {
        List<Item> items = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String itemCode = parts[0];
                    String itemName = parts[1];
                    String supplierId = parts[2];
                    items.add(new Item(itemCode, itemName, supplierId));
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading items.txt: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return items;
    }

    // Closes this window and re-open the main menu
    private void closeAndReturnToMainMenu() {
        dispose(); 
        mainMenu.setVisible(true); 
    }
}
