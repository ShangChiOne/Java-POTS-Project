package gui;

import models.Item;
import models.ItemDatabase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class StockLevelUpdateForm extends JFrame {
    private JComboBox<String> itemDropdown;
    private JTextField quantityField;
    private JTextField reorderLevelField;
    private JButton addButton;
    private JButton editButton;
    private JButton backButton;
    private JFrame previousPage;

    public StockLevelUpdateForm(JFrame previousPage) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);

        // Frame Setup
        setTitle("Manage Stock Levels");
        setSize(600, 600);
        setLocationRelativeTo(null); // Center on screen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); // Black background

        // Title label
        JLabel titleLabel = new JLabel("Update Stock Levels", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20)); 
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(150, 40, 300, 30);
        add(titleLabel);

        // Labels and Input Fields
        JLabel itemLabel = new JLabel("Select Item:");
        itemLabel.setFont(new Font("Arial", Font.BOLD, 16)); 
        itemLabel.setForeground(Color.WHITE);
        itemLabel.setBounds(100, 120, 150, 30); 
        add(itemLabel);

        itemDropdown = new JComboBox<>();
        populateItemDropdown();
        itemDropdown.setFont(new Font("Arial", Font.PLAIN, 14)); 
        itemDropdown.setBounds(300, 120, 200, 30);
        add(itemDropdown);

        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setFont(new Font("Arial", Font.BOLD, 16));
        quantityLabel.setForeground(Color.WHITE);
        quantityLabel.setBounds(100, 180, 150, 30);
        add(quantityLabel);

        quantityField = new JTextField();
        quantityField.setFont(new Font("Arial", Font.PLAIN, 14));
        quantityField.setBounds(300, 180, 200, 30);
        add(quantityField);

        JLabel reorderLevelLabel = new JLabel("Reorder Level:");
        reorderLevelLabel.setFont(new Font("Arial", Font.BOLD, 16));
        reorderLevelLabel.setForeground(Color.WHITE);
        reorderLevelLabel.setBounds(100, 240, 150, 30);
        add(reorderLevelLabel);

        reorderLevelField = new JTextField();
        reorderLevelField.setFont(new Font("Arial", Font.PLAIN, 14));
        reorderLevelField.setBounds(300, 240, 200, 30);
        add(reorderLevelField);

        // Buttons
        addButton = new JButton("Add");
        addButton.setFont(new Font("Arial", Font.BOLD, 16)); 
        addButton.setBounds(150, 340, 120, 40);
        addButton.setBackground(new Color(11, 136, 255)); 
        addButton.setForeground(Color.BLACK);
        addButton.addActionListener(this::handleAddButton);
        add(addButton);

        editButton = new JButton("Edit Stock Levels");
        editButton.setFont(new Font("Arial", Font.BOLD, 16)); 
        editButton.setBounds(200, 400, 200, 40);
        editButton.setBackground(new Color(0, 204, 0)); 
        editButton.setForeground(Color.BLACK);
        editButton.addActionListener(e -> openEditStockLevelForm());
        add(editButton);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        backButton.setBounds(300, 340, 120, 40);
        backButton.setBackground(new Color(255, 140, 0)); 
        backButton.setForeground(Color.BLACK);
        backButton.addActionListener(e -> {
            dispose();
            previousPage.setVisible(true);
        });
        add(backButton);
    }
    
    // Clear input fields
    private void clearFields() {
        quantityField.setText("");
        reorderLevelField.setText("");
        itemDropdown.setSelectedIndex(0); 
    }

    // Populate the item dropdown with item codes from the database
    private void populateItemDropdown() {
        List<Item> items = ItemDatabase.getAllItems();
        for (Item item : items) {
            // Populate dropdown with ItemCode only
            itemDropdown.addItem(item.getItemCode());
        }
    }

    // Handle the add button click event
    private void handleAddButton(ActionEvent e) {
        String selectedItemCode = (String) itemDropdown.getSelectedItem();
        if (selectedItemCode == null || selectedItemCode.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select an item.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String quantityText = quantityField.getText();
        String reorderLevelText = reorderLevelField.getText();

        try {
            int quantity = Integer.parseInt(quantityText);
            int reorderLevel = Integer.parseInt(reorderLevelText);

            // Save stock information to the StockLevels file
            boolean isAdded = saveStockInformation(selectedItemCode, quantity, reorderLevel);
            if (isAdded) {
                JOptionPane.showMessageDialog(this, "Stock information added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                quantityField.setText("");
                reorderLevelField.setText("");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for quantity and reorder level.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Save stock information to a file
    private boolean saveStockInformation(String itemCode, int quantity, int reorderLevel) {
        Item item = ItemDatabase.getItemByCode(itemCode); 

        if (item == null) {
            JOptionPane.showMessageDialog(this, "Item not found in the database.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String itemName = item.getItemName(); 
        List<String[]> stockLevels = readStockLevels();

        // Check if item already exists
        for (String[] stock : stockLevels) {
            if (stock[0].equals(itemCode)) {
                JOptionPane.showMessageDialog(this, "Item already exists in stock levels.", "Duplicate Entry", JOptionPane.WARNING_MESSAGE);
                clearFields();
                return false; 
            }
    }

    // Append the new stock entry to the file
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("StockLevels.txt", true))) {
        writer.write(itemCode + "," + itemName + "," + quantity + "," + reorderLevel);
        writer.newLine();
        return true; 
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(this, "Error saving stock information: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        return false; 
    }
    
    }

    // Read stock levels from the file
    private List<String[]> readStockLevels() {
        List<String[]> stockData = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("StockLevels.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stockData.add(line.split(","));
            }
        } catch (IOException ex) {
            System.err.println("Error reading stock levels: " + ex.getMessage());
        }
        return stockData;
    }

    // Open the Edit Stock Level form
    private void openEditStockLevelForm() {
        new EditStockLevelForm(this).setVisible(true);
    }
}
