package gui;

import javax.swing.*;
import java.awt.*;
import models.PurchaseOrder;
import models.PurchaseOrderDatabase;
import models.PurchaseRequisition;
import models.RequisitionDatabase;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.UUID;

public class PurchaseOrderForm extends JFrame {
    private JComboBox<String> requisitionComboBox;
    private JComboBox<String> purchaseOrderComboBox;
    private JTextField itemCodeField;
    private JTextField quantityField;
    private JTextField supplierIdField;
    private JButton generatePOButton;
    private JButton editPOButton;
    private JButton deletePOButton;
    private JButton backButton;
    private JFrame previousPage;

    public PurchaseOrderForm(JFrame previousPage) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);
        
        // Frame Setup
        setTitle("Purchase Order Management");
        setSize(600, 700);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK);

        // Purchase Order selection dropdown for editing/deletion
        JLabel poLabel = new JLabel("Select Purchase Order:");
        poLabel.setFont(new Font("Arial", Font.BOLD, 16));
        poLabel.setForeground(Color.WHITE);
        poLabel.setBounds(150, 20, 300, 30);
        add(poLabel);

        purchaseOrderComboBox = new JComboBox<>();
        purchaseOrderComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        purchaseOrderComboBox.setBackground(new Color(105, 105, 105));
        purchaseOrderComboBox.setForeground(Color.WHITE);
        purchaseOrderComboBox.setBounds(150, 50, 300, 30);
        populatePurchaseOrderComboBox();
        purchaseOrderComboBox.addActionListener(e -> loadPurchaseOrderDetails());
        add(purchaseOrderComboBox);

        // Requisition selection dropdown
        JLabel requisitionLabel = new JLabel("Select Requisition:");
        requisitionLabel.setFont(new Font("Arial", Font.BOLD, 16));
        requisitionLabel.setForeground(Color.WHITE);
        requisitionLabel.setBounds(150, 90, 300, 30);
        add(requisitionLabel);

        requisitionComboBox = new JComboBox<>();
        requisitionComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        requisitionComboBox.setBackground(new Color(105, 105, 105));
        requisitionComboBox.setForeground(Color.WHITE);
        requisitionComboBox.setBounds(150, 120, 300, 30);
        populateRequisitionComboBox();
        requisitionComboBox.addActionListener(e -> loadRequisitionDetails());
        add(requisitionComboBox);

        // Item Code field
        JLabel itemCodeLabel = new JLabel("Item Code:");
        itemCodeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        itemCodeLabel.setForeground(Color.WHITE);
        itemCodeLabel.setBounds(150, 160, 300, 30);
        add(itemCodeLabel);

        itemCodeField = new JTextField();
        itemCodeField.setFont(new Font("Arial", Font.PLAIN, 14));
        itemCodeField.setBackground(new Color(105, 105, 105));
        itemCodeField.setForeground(Color.WHITE);
        itemCodeField.setBounds(150, 190, 300, 30);
        add(itemCodeField);

        // Quantity field
        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setFont(new Font("Arial", Font.BOLD, 16));
        quantityLabel.setForeground(Color.WHITE);
        quantityLabel.setBounds(150, 230, 300, 30);
        add(quantityLabel);

        quantityField = new JTextField();
        quantityField.setFont(new Font("Arial", Font.PLAIN, 14));
        quantityField.setBackground(new Color(105, 105, 105));
        quantityField.setForeground(Color.WHITE);
        quantityField.setBounds(150, 260, 300, 30);
        add(quantityField);

        // Supplier ID field
        JLabel supplierIdLabel = new JLabel("Supplier ID:");
        supplierIdLabel.setFont(new Font("Arial", Font.BOLD, 16));
        supplierIdLabel.setForeground(Color.WHITE);
        supplierIdLabel.setBounds(150, 300, 300, 30);
        add(supplierIdLabel);

        supplierIdField = new JTextField();
        supplierIdField.setFont(new Font("Arial", Font.PLAIN, 14));
        supplierIdField.setBackground(new Color(105, 105, 105));
        supplierIdField.setForeground(Color.WHITE);
        supplierIdField.setBounds(150, 330, 300, 30);
        add(supplierIdField);

        // Generate PO button
        generatePOButton = new JButton("Generate PO");
        generatePOButton.setFont(new Font("Arial", Font.BOLD, 14));
        generatePOButton.setBackground(new Color(11, 136, 255));
        generatePOButton.setBounds(150, 390, 140, 40);
        generatePOButton.addActionListener(e -> generatePurchaseOrder());
        add(generatePOButton);

        // Edit PO button
        editPOButton = new JButton("Edit PO");
        editPOButton.setFont(new Font("Arial", Font.BOLD, 14));
        editPOButton.setBackground(new Color(255, 215, 0));
        editPOButton.setBounds(310, 390, 140, 40);
        editPOButton.addActionListener(e -> editPurchaseOrder());
        add(editPOButton);

        // Delete PO button
        deletePOButton = new JButton("Delete PO");
        deletePOButton.setFont(new Font("Arial", Font.BOLD, 14));
        deletePOButton.setBackground(new Color(255, 69, 0));
        deletePOButton.setBounds(150, 450, 300, 40);
        deletePOButton.addActionListener(e -> deletePurchaseOrder());
        add(deletePOButton);

        // Back button
        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0));
        backButton.setBounds(150, 510, 300, 40);
        backButton.addActionListener(e -> goBack());
        add(backButton);
    }

    // Populate the requisition dropdown
    private void populateRequisitionComboBox() {
        for (PurchaseRequisition requisition : RequisitionDatabase.getAllRequisitions()) {
            requisitionComboBox.addItem(requisition.getRequisitionId());
        }
    }

     // Populate the purchase order dropdown
    private void populatePurchaseOrderComboBox() {
        purchaseOrderComboBox.removeAllItems();
        for (PurchaseOrder purchaseOrder : PurchaseOrderDatabase.getAllPurchaseOrders()) {
            purchaseOrderComboBox.addItem(purchaseOrder.getPurchaseOrderId());
        }
    }

    // Load details for the selected requisition
    private void loadRequisitionDetails() {
        String selectedRequisitionId = (String) requisitionComboBox.getSelectedItem();
        PurchaseRequisition requisition = RequisitionDatabase.getAllRequisitions().stream()
                .filter(r -> r.getRequisitionId().equals(selectedRequisitionId))
                .findFirst()
                .orElse(null);

        if (requisition != null) {
            itemCodeField.setText(requisition.getItemCode());
            quantityField.setText(String.valueOf(requisition.getQuantity()));
            supplierIdField.setText(requisition.getSupplierCode());
        }
    }

    // Load details for the selected purchase order
    private void loadPurchaseOrderDetails() {
        String selectedOrderId = (String) purchaseOrderComboBox.getSelectedItem();
        PurchaseOrder purchaseOrder = PurchaseOrderDatabase.getAllPurchaseOrders().stream()
                .filter(po -> po.getPurchaseOrderId().equals(selectedOrderId))
                .findFirst()
                .orElse(null);

        if (purchaseOrder != null) {
            requisitionComboBox.setSelectedItem(purchaseOrder.getRequisitionId());
            itemCodeField.setText(purchaseOrder.getItemCode());
            quantityField.setText(String.valueOf(purchaseOrder.getQuantity()));
            supplierIdField.setText(purchaseOrder.getSupplierId());
        }
    }

    // Generate a new Purchase Order
    private void generatePurchaseOrder() {
        String requisitionId = (String) requisitionComboBox.getSelectedItem();
        String itemCode = itemCodeField.getText();
        String quantityText = quantityField.getText();
        String supplierId = supplierIdField.getText();

        if (requisitionId == null || requisitionId.isEmpty() ||
            itemCode.isEmpty() || quantityText.isEmpty() || supplierId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields before generating a PO.");
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantity must be a valid number.");
            return;
        }

        // Check for duplicates in the existing purchase orders
        for (PurchaseOrder existing : PurchaseOrderDatabase.getAllPurchaseOrders()) {
            if (existing.getRequisitionId().equalsIgnoreCase(requisitionId) 
                    || existing.getItemCode().equalsIgnoreCase(itemCode)) {
                JOptionPane.showMessageDialog(this, 
                    "A Purchase Order for this Requisition ID or Item Code already exists.",
                    "Duplicate Purchase Order", 
                    JOptionPane.WARNING_MESSAGE);
                return; 
            }
        }

        String purchaseOrderId = "PO-" + UUID.randomUUID().toString().substring(0, 8);
        PurchaseOrder purchaseOrder = new PurchaseOrder(purchaseOrderId, requisitionId, itemCode, quantity, supplierId);
        PurchaseOrderDatabase.addPurchaseOrder(purchaseOrder);

        JOptionPane.showMessageDialog(this, "Purchase Order generated successfully!\nPO ID: " + purchaseOrderId);
        clearForm();
        populatePurchaseOrderComboBox(); 
    }


    // Edit the selected Purchase Order
    private void editPurchaseOrder() {
        String selectedOrderId = (String) purchaseOrderComboBox.getSelectedItem();
        String requisitionId = (String) requisitionComboBox.getSelectedItem();
        String itemCode = itemCodeField.getText();
        String quantityText = quantityField.getText();
        String supplierId = supplierIdField.getText();

        if (selectedOrderId == null || requisitionId == null || itemCode.isEmpty() || quantityText.isEmpty() || supplierId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields to edit the Purchase Order.");
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantity must be a valid number.");
            return;
        }

        PurchaseOrder updatedOrder = new PurchaseOrder(selectedOrderId, requisitionId, itemCode, quantity, supplierId);
        PurchaseOrderDatabase.updatePurchaseOrder(updatedOrder);

        JOptionPane.showMessageDialog(this, "Purchase Order updated successfully!");
        clearForm();
    }

    // Delete the selected Purchase Order
    private void deletePurchaseOrder() {
        String selectedOrderId = (String) purchaseOrderComboBox.getSelectedItem();
        if (selectedOrderId != null) {
            PurchaseOrderDatabase.deletePurchaseOrder(selectedOrderId);
            JOptionPane.showMessageDialog(this, "Purchase Order deleted successfully!");
            clearForm();
            populatePurchaseOrderComboBox(); 
        } else {
            JOptionPane.showMessageDialog(this, "Please select a Purchase Order to delete.");
        }
    }

    // Clear the form fields
    private void clearForm() {
        requisitionComboBox.setSelectedIndex(0);
        purchaseOrderComboBox.setSelectedIndex(-1);
        itemCodeField.setText("");
        quantityField.setText("");
        supplierIdField.setText("");
    }

    // Navigate back to the previous page
    private void goBack() {
        this.dispose();
        previousPage.setVisible(true);
    }
}
