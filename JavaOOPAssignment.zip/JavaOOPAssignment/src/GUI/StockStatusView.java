package gui;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class StockStatusView extends JFrame {
    private JTable stockTable;
    private JButton backButton, generateChartButton;
    private JFrame previousPage;

    // Frame Setup  
    public StockStatusView(JFrame previousPage) {
        this.previousPage = previousPage;
        previousPage.setVisible(false);
        setTitle("Stock Status");
        setSize(700, 600);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        // Title label
        JLabel titleLabel = new JLabel("Stock Status", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(200, 10, 300, 30);
        add(titleLabel);

        // Load stock data from StockLevels.txt and create table
        String[] columnNames = {"Item Code", "Item Name", "Quantity", "Reorder Level"};
        List<String[]> stockData = loadStockLevels();
        String[][] data = new String[stockData.size()][4];

        for (int i = 0; i < stockData.size(); i++) {
            String[] stock = stockData.get(i);
            data[i][0] = stock[0]; 
            data[i][1] = stock[1]; 
            data[i][2] = stock[2]; 
            data[i][3] = stock[3]; 
        }

        stockTable = new JTable(data, columnNames);
        stockTable.setFont(new Font("Arial", Font.PLAIN, 14));
        stockTable.setBackground(new Color(105, 105, 105)); 
        stockTable.setForeground(Color.WHITE); 
        stockTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        stockTable.getTableHeader().setBackground(new Color(255, 140, 0)); 
        stockTable.getTableHeader().setForeground(Color.WHITE); 

        JScrollPane scrollPane = new JScrollPane(stockTable);
        scrollPane.setBounds(50, 60, 600, 400);
        add(scrollPane);

        // Back Button
        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0)); 
        backButton.setForeground(Color.BLACK); 
        backButton.setBounds(50, 480, 200, 40);
        backButton.addActionListener(e -> {
            dispose();
            previousPage.setVisible(true);
        });
        add(backButton);

        // Generate Chart Button
        generateChartButton = new JButton("Generate Bar Chart");
        generateChartButton.setFont(new Font("Arial", Font.BOLD, 14));
        generateChartButton.setBackground(new Color(50, 205, 50)); 
        generateChartButton.setForeground(Color.BLACK); 
        generateChartButton.setBounds(450, 480, 200, 40);
        generateChartButton.addActionListener(e -> generateBarChart(stockData));
        add(generateChartButton);
    }

    // Load stock data from StockLevels.txt
    private List<String[]> loadStockLevels() {
        List<String[]> stockData = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("StockLevels.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stockData.add(line.split(",")); 
            }
        } catch (FileNotFoundException e) {
            System.err.println("StockLevels.txt file not found.");
            JOptionPane.showMessageDialog(this, "StockLevels.txt file not found.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException e) {
            System.err.println("Error reading StockLevels.txt: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error reading StockLevels.txt.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return stockData;
    }

    // Generate Bar Chart
    private void generateBarChart(List<String[]> stockData) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        for (String[] stock : stockData) {
            String itemName = stock[1];
            int quantity = Integer.parseInt(stock[2]);
            dataset.addValue(quantity, "Stock Level", itemName);
        }

        JFreeChart barChart = ChartFactory.createBarChart(
                "Stock Levels", 
                "Item Name",    
                "Quantity",     
                dataset
        );
        
        org.jfree.chart.plot.CategoryPlot plot = barChart.getCategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer renderer = (org.jfree.chart.renderer.category.BarRenderer) plot.getRenderer();

        // Colors of the bars
        renderer.setSeriesPaint(0, new java.awt.Color(255, 140, 0)); 

        // Display the chart in a new JFrame
        JFrame chartFrame = new JFrame("Stock Levels Bar Chart");
        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new Dimension(800, 700));
        chartFrame.add(chartPanel);
        chartFrame.pack();
        chartFrame.setLocationRelativeTo(this);
        chartFrame.setVisible(true);
    }
}
