package gui;

import javax.swing.*;
import java.awt.*;
import models.PurchaseOrder;
import models.PurchaseOrderDatabase;
import models.User;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PurchaseOrderApprovalForm extends JFrame {
    private JComboBox<String> purchaseOrderComboBox;
    private JTextField itemCodeField;
    private JTextField quantityField;
    private JTextField supplierIdField;
    private JTextField statusField;
    private JTextArea rejectionReasonArea;
    private JButton approveButton;
    private JButton rejectButton;
    private JButton backButton;
    private JFrame previousPage;
    private User user;

    public PurchaseOrderApprovalForm(JFrame previousPage, User user) {
        this.previousPage = previousPage;
        this.user = user;
        previousPage.setVisible(false);
  
        // Frame Setup
        setTitle("Approve/Reject Purchase Orders");
        setSize(600, 600);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.BLACK); 

        // Purchase Order selection dropdown
        JLabel poLabel = new JLabel("Select Purchase Order:");
        poLabel.setFont(new Font("Arial", Font.BOLD, 16));
        poLabel.setForeground(Color.WHITE);
        poLabel.setBounds(150, 20, 300, 30);
        add(poLabel);

        purchaseOrderComboBox = new JComboBox<>();
        purchaseOrderComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        purchaseOrderComboBox.setBackground(new Color(105, 105, 105)); 
        purchaseOrderComboBox.setForeground(Color.WHITE); 
        purchaseOrderComboBox.setBounds(150, 50, 300, 30);
        populatePurchaseOrderComboBox();
        purchaseOrderComboBox.addActionListener(e -> loadPurchaseOrderDetails());
        add(purchaseOrderComboBox);

        // Item Code field
        JLabel itemCodeLabel = new JLabel("Item Code:");
        itemCodeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        itemCodeLabel.setForeground(Color.WHITE);
        itemCodeLabel.setBounds(150, 90, 300, 30);
        add(itemCodeLabel);

        itemCodeField = new JTextField();
        itemCodeField.setFont(new Font("Arial", Font.PLAIN, 14));
        itemCodeField.setBackground(new Color(105, 105, 105)); 
        itemCodeField.setForeground(Color.WHITE); 
        itemCodeField.setBounds(150, 120, 300, 30);
        itemCodeField.setEditable(false);
        add(itemCodeField);

        // Quantity field
        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setFont(new Font("Arial", Font.BOLD, 16));
        quantityLabel.setForeground(Color.WHITE);
        quantityLabel.setBounds(150, 160, 300, 30);
        add(quantityLabel);

        quantityField = new JTextField();
        quantityField.setFont(new Font("Arial", Font.PLAIN, 14));
        quantityField.setBackground(new Color(105, 105, 105)); 
        quantityField.setForeground(Color.WHITE);
        quantityField.setBounds(150, 190, 300, 30);
        quantityField.setEditable(false);
        add(quantityField);

        // Supplier ID field
        JLabel supplierIdLabel = new JLabel("Supplier ID:");
        supplierIdLabel.setFont(new Font("Arial", Font.BOLD, 16));
        supplierIdLabel.setForeground(Color.WHITE);
        supplierIdLabel.setBounds(150, 230, 300, 30);
        add(supplierIdLabel);

        supplierIdField = new JTextField();
        supplierIdField.setFont(new Font("Arial", Font.PLAIN, 14));
        supplierIdField.setBackground(new Color(105, 105, 105));
        supplierIdField.setForeground(Color.WHITE);
        supplierIdField.setBounds(150, 260, 300, 30);
        supplierIdField.setEditable(false);
        add(supplierIdField);

        // Status field
        JLabel statusLabel = new JLabel("Status:");
        statusLabel.setFont(new Font("Arial", Font.BOLD, 16));
        statusLabel.setForeground(Color.WHITE);
        statusLabel.setBounds(150, 300, 300, 30);
        add(statusLabel);

        statusField = new JTextField();
        statusField.setFont(new Font("Arial", Font.PLAIN, 14));
        statusField.setBackground(new Color(105, 105, 105));
        statusField.setForeground(Color.WHITE);
        statusField.setBounds(150, 330, 300, 30);
        statusField.setEditable(false);
        add(statusField);

        // Rejection reason
        JLabel reasonLabel = new JLabel("Rejection Reason:");
        reasonLabel.setFont(new Font("Arial", Font.BOLD, 16));
        reasonLabel.setForeground(Color.WHITE);
        reasonLabel.setBounds(150, 370, 300, 30);
        add(reasonLabel);

        rejectionReasonArea = new JTextArea();
        rejectionReasonArea.setFont(new Font("Arial", Font.PLAIN, 14));
        rejectionReasonArea.setBackground(new Color(105, 105, 105));
        rejectionReasonArea.setForeground(Color.WHITE);
        rejectionReasonArea.setBounds(150, 400, 300, 60);
        add(rejectionReasonArea);

        // Approve, Reject, and Back buttons on the same line
        approveButton = new JButton("Approve");
        approveButton.setFont(new Font("Arial", Font.BOLD, 14));
        approveButton.setBackground(new Color(11, 136, 255)); 
        approveButton.setBounds(70, 480, 120, 40);
        approveButton.addActionListener(e -> approvePurchaseOrder());
        add(approveButton);

        rejectButton = new JButton("Reject");
        rejectButton.setFont(new Font("Arial", Font.BOLD, 14));
        rejectButton.setBackground(new Color(211, 211, 211)); 
        rejectButton.setBounds(240, 480, 120, 40);
        rejectButton.addActionListener(e -> rejectPurchaseOrder());
        add(rejectButton);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 140, 0)); 
        backButton.setBounds(410, 480, 120, 40);
        backButton.addActionListener(e -> goBack());
        add(backButton);
    }

    // Populates the dropdown with all purchase orders
    private void populatePurchaseOrderComboBox() {
        purchaseOrderComboBox.removeAllItems();
        for (PurchaseOrder purchaseOrder : PurchaseOrderDatabase.getAllPurchaseOrders()) {
            purchaseOrderComboBox.addItem(purchaseOrder.getPurchaseOrderId());
        }
    }

    // Loads the details of the selected purchase order into the form fields
    private void loadPurchaseOrderDetails() {
        String selectedOrderId = (String) purchaseOrderComboBox.getSelectedItem();
        PurchaseOrder order = PurchaseOrderDatabase.getAllPurchaseOrders().stream()
                .filter(po -> po.getPurchaseOrderId().equals(selectedOrderId))
                .findFirst()
                .orElse(null);

        if (order != null) {
            itemCodeField.setText(order.getItemCode());
            quantityField.setText(String.valueOf(order.getQuantity()));
            supplierIdField.setText(order.getSupplierId());
            statusField.setText(order.isApproved() ? "Approved" : "Pending");
            rejectionReasonArea.setText(order.getRejectionReason());
        }
    }

    // Approves the selected purchase order
    private void approvePurchaseOrder() {
        String selectedOrderId = (String) purchaseOrderComboBox.getSelectedItem();
        PurchaseOrder order = PurchaseOrderDatabase.getAllPurchaseOrders().stream()
                .filter(po -> po.getPurchaseOrderId().equals(selectedOrderId))
                .findFirst()
                .orElse(null);

        if (order != null) {
            order.approve();
            PurchaseOrderDatabase.updatePurchaseOrder(order);
            JOptionPane.showMessageDialog(this, "Purchase Order Approved!");
            loadPurchaseOrderDetails();
        }
    }

    // Rejects the selected purchase order with a reason
    private void rejectPurchaseOrder() {
        String selectedOrderId = (String) purchaseOrderComboBox.getSelectedItem();
        PurchaseOrder order = PurchaseOrderDatabase.getAllPurchaseOrders().stream()
                .filter(po -> po.getPurchaseOrderId().equals(selectedOrderId))
                .findFirst()
                .orElse(null);

        if (order != null) {
            String reason = rejectionReasonArea.getText().trim();
            if (reason.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please provide a rejection reason.");
                return;
            }
            order.reject(reason);
            PurchaseOrderDatabase.updatePurchaseOrder(order);
            JOptionPane.showMessageDialog(this, "Purchase Order Rejected!");
            loadPurchaseOrderDetails();
        }
    }
    
    // Returns to the previous page
    private void goBack() {
        this.dispose(); 
        previousPage.setVisible(true); 
    }
}
